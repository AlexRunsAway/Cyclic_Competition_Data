%% Main Menu
function Main_Menu
%% Menu overview

% 1. input data set (win-loss, ties data, extra win frequency distribution,
% names)
% 2. input settings (either pick default or set by hand, give option to
% reset to default for each setting, or to save custom settings as a custom
% default)

% settings categories
% 1. prior settings
% 2. whether to use asymptotic correctors on point estimates
% 3. whether to sample from posterior to validate point estimates/quantify
% uncertainty
% 4. whether to do hypothesis testing
% 5. whether to get plausible region
% 6. what to print/display
% 7. filename to save output to

% structure:
% 1. calls data menu. user inputs data
% 2. which calls settings menu. user inputs settings
% 3. which calls review and run menu


%% Clear
clear
close all

%% formatting
format.margin = 0.05;
format.font_big = 14;
format.font_medium = 11;
format.font_small = 10;
format.grey_color = [0.91,0.91,0.91];
format.button_color = [1,1,1];


%% call input data menu
data_menu(format)
end