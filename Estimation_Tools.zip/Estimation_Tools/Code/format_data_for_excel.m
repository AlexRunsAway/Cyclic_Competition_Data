function row = format_data_for_excel(input)


%% topology
dimensions = input.dimensions;

row{1} = dimensions.V;
row{2} = dimensions.E;
row{3} = dimensions.L;
if input.topology.complete_flag == 1
    row{4} = 'Yes';
else
    row{4} = 'No';
end
row{5} = dimensions.E/(dimensions.V*(dimensions.V - 1)/2);

%% data quality
data = input.data;

row{6} = sum(data.events);
row{7} = row{6}/dimensions.E;
row{8} = min([data.wins;data.losses]);
row{9} = 100*sum([data.wins;data.losses] == 0)/dimensions.E;

%% additional data
assumptions = input.input.settings.assumptions;

if assumptions.ties == 0
    row{10} = 'No';
else
    row{10} = 'Yes';
end

if assumptions.use_outside_win_freq == 0
    row{11} = 'No';
else
    row{11} = 'Yes';
end

%% Prior
if assumptions.ties == 1
    row{12} = assumptions.tie_weighting;
else
    row{12} = ' ';
end

row{13} = input.prior.beta;

prior_modes = {'Uniform','Jefferys','Haldane','Custom ','MAP'};
row{14} = prior_modes{assumptions.prior_mode};

%% rating and ranking
order = input.ranking.mle;
names = input.input.names{1};

row{15} = names{order(1)};
row{16} = names{order(2)};
row{17} = names{order(3)};
row{18} = names{order(end)};

row{19} = max(input.rating.mle);
row{20} = min(input.rating.mle);

row{21} = max(sqrt(input.rating.sampled.post.var));
row{22} = mean(sqrt(input.rating.sampled.post.var));

row{23} = input.ranking.sampled.post.correlation.Kendall;
row{24} = input.ranking.sampled.post.correlation.Spearman;

%% measures
measures = input.measures;

row{25} = measures.total.mle/sqrt(dimensions.E);

row{26} = measures.transitivity.mle/sqrt(dimensions.E);
row{27} = sqrt(measures.transitivity.sampled.post.variance)/sqrt(dimensions.E);
row{28} = measures.transitivity.sampled.post.lower/sqrt(dimensions.E);
row{29} = measures.transitivity.sampled.post.upper/sqrt(dimensions.E);
if strcmp(measures.plausible_bounds.trans.lower_stop_flag,'stopped on convergence to desired plausibility') || ...
        strcmp(measures.plausible_bounds.trans.lower_stop_flag,'lower bound plausible for bounds >= 10^(-10)')
    row{30} = measures.plausible_bounds.trans.lower/sqrt(dimensions.E);
else
    row{30} = 'Not Found';
end
if strcmp(measures.plausible_bounds.trans.upper_stop_flag,'stopped on convergence to desired plausibility')
    row{31} = measures.plausible_bounds.trans.upper/sqrt(dimensions.E);
else
    row{31} = 'Not Found';
end
row{32} = measures.percent_from_noise.trans;


row{33} = measures.intransitivity.mle/sqrt(dimensions.E);
row{34} = sqrt(measures.intransitivity.sampled.post.variance)/sqrt(dimensions.E);
row{35} = measures.intransitivity.sampled.post.lower/sqrt(dimensions.E);
row{36} = measures.intransitivity.sampled.post.upper/sqrt(dimensions.E);
if strcmp(measures.plausible_bounds.intrans.lower_stop_flag,'stopped on convergence to desired plausibility') || ...
        strcmp(measures.plausible_bounds.intrans.lower_stop_flag,'lower bound plausible for bounds >= 10^(-10)')
    row{37} = measures.plausible_bounds.intrans.lower/sqrt(dimensions.E);
else
    row{37} = 'Not Found';
end
if strcmp(measures.plausible_bounds.intrans.upper_stop_flag,'stopped on convergence to desired plausibility')
    row{38} = measures.plausible_bounds.intrans.upper/sqrt(dimensions.E);
else
    row{38} = 'Not Found';
end
row{39} = measures.percent_from_noise.intrans;

row{40} = measures.intransitivity.rel.mle;
row{41} = sqrt(measures.intransitivity.sampled.post.rel.variance);
row{42} = measures.intransitivity.sampled.post.rel.lower;
row{43} = measures.intransitivity.sampled.post.rel.upper;

row{44} = measures.transitivity.sampled.kolmogorov_post_prior;
row{45} = measures.intransitivity.sampled.kolmogorov_post_prior;

%% correlation and relative intransitivity
row{46} = measures.rho.mle;
row{47} = sqrt(measures.rho.sampled.post.variance);
row{48} = measures.rho.sampled.post.lower;
row{49} = measures.rho.sampled.post.upper;
row{50} = (1 - 2*row{46})*dimensions.L/dimensions.E;
row{51} = measures.intransitivity.rel.mle^2;

%% strong cyclic edges
[~,order] = sort(abs(input.f.rot.mle),'descend');
edge_to_endpoints = input.topology.edge_to_endpoints;

for j = 1:5
    if j <= dimensions.E
        start = edge_to_endpoints(order(j),1);
        finish = edge_to_endpoints(order(j),2);
        sign_of_flow= sign(input.f.mle(order(j)));
        
        if sign_of_flow == 1
            row{52 + 2*(j-1)} = strcat(names{start},{' '},'>',{' '},names{finish});
        else
            row{52 + 2*(j-1)} = strcat(names{finish},{' '},'>',{' '},names{start});
        end
        
        row{52 + 2*(j-1) + 1} = abs(input.f.rot.mle(order(j)));
    else
        row{52 + 2*(j-1)} = ' ';
        row{52 + 2*(j-1) + 1} = ' ';
    end
end

%% hypothesis testing

row{62} = input.hypothesis_testing.mle.match_to_data.log_likelihood;
row{63} = input.hypothesis_testing.perfectly_transitive.match_to_data.log_likelihood;
row{64} = 2*(row{62} - row{63});
row{65} = input.hypothesis_testing.perfectly_cyclic.match_to_data.log_likelihood;
row{66} = 2*(row{62} - row{65});


row{67} = input.hypothesis_testing.mle.match_to_data.AIC;
row{68} = input.hypothesis_testing.perfectly_transitive.match_to_data.AIC;
row{69} = row{68} - row{67};
row{70} = input.hypothesis_testing.perfectly_cyclic.match_to_data.AIC;
row{71} = row{70} - row{67};

row{72} = 100*input.hypothesis_testing.mle.match_to_data.percent_edges_in_50;
row{73} = 100*input.hypothesis_testing.perfectly_transitive.match_to_data.percent_edges_in_50;
row{74} = 100*input.hypothesis_testing.perfectly_cyclic.match_to_data.percent_edges_in_50;

row{75} = 100*input.hypothesis_testing.mle.match_to_data.percent_edges_in_95;
row{76} = 100*input.hypothesis_testing.perfectly_transitive.match_to_data.percent_edges_in_95;
row{77} = 100*input.hypothesis_testing.perfectly_cyclic.match_to_data.percent_edges_in_95;

row{78} = input.hypothesis_testing.mle.match_to_data.plausibility;
row{79} = input.hypothesis_testing.perfectly_transitive.match_to_data.plausibility;
row{80} = input.hypothesis_testing.perfectly_cyclic.match_to_data.plausibility;

%% worst match to data for MAP perfectly transitive model
agreement = input.hypothesis_testing.perfectly_transitive.match_to_data_per_edge.p_test_two_sided;
[~,order] = sort(agreement,'ascend');

for j = 1:5
    if j <= dimensions.E
        edge = order(j);
        start = edge_to_endpoints(edge,1);
        finish = edge_to_endpoints(edge,2);
        sign_of_flow= sign(input.f.mle(edge));
        
        if sign_of_flow == 1
            row{81 + 2*(j-1)} = strcat(names{start},{' '},'>',{' '},names{finish});
        else
            row{81 + 2*(j-1)} = strcat(names{finish},{' '},'>',{' '},names{start});
        end
        
        row{81 + 2*(j-1) + 1} = agreement(edge);
    
    else
        row{81 + 2*(j-1)} = ' ';
        row{81 + 2*(j-1) + 1} = ' ';
    end


end