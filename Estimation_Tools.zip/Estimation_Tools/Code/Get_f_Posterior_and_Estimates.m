function [f,posterior_f] = Get_f_Posterior_and_Estimates(Wins,Losses,gamma,E,edge_to_endpoints)
%% preallocate
f.empirical = nan([E,1]);
f.mle = nan([E,1]);
f.exp = nan([E,1]);
f.variance_in_post = nan([E,1]);


%% loop over edges
for k = 1:E
    
    %% get endpoints
    i = edge_to_endpoints(k,1);
    j = edge_to_endpoints(k,2);
    
    %% get wins and losses
    w = Wins(i,j);
    l = Losses(i,j);
    if length(gamma) == E
        g = gamma(k);
    else
        g = gamma;
    end
    
    posterior_p = @(p) ((p.^(w + g - 1)).*(1-p).^(l + g - 1)); % Note: this is not normalized
    win_prob = @(f) (1 + exp(-2*f)).^(-1);
    
    posterior_f{k} = @(f) posterior_p(win_prob(f))./(2*cosh(f).^2);
    
    %% compute empirical forces, expected force, and maximum likelihood force
    f.empirical(k) = (1/2)*(log(w/l)); % logit of observed win frequency
    f.exp(k) = (1/2)*(psi(w + g) - psi(l + g)); % psi is the digamma function
    f.mle(k) = (1/2)*log((w + g)/(l + g));
    
    %% compute variance in posterior forces
    f.variance_in_post(k) = (psi(1,w + g) + psi(1,l + g))/4;
    
    
end

end
