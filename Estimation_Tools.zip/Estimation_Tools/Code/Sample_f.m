function [transitivity,intransitivity,rho,ratings,ranking] = Sample_f(n_real,V,E,posterior_f,f,f_range,G,complete_flag,confidence)
%% Preallocate
ratings_samples = zeros([V,n_real]);
rank_samples = zeros([V,n_real]);
f_samples.full = zeros([E,n_real]);
f_samples.con = zeros([E,n_real]);
f_samples.rot = zeros([E,n_real]);

%% form discrete posteriors
fs = linspace(f_range(1),f_range(2),10^4);
df = fs(2) - fs(1);
for k = 1:E
    post{k} = posterior_f{k}(fs)*df;
    post{k} = post{k}/sum(post{k});
end



%% Sample
for m = 1:n_real % loop over realizations
    
    %% sample forces
    f_sample = zeros([E,1]);
    for k = 1:E 
        
        if isnan(max(post{k})) == 0
            zeta = rand;
            cdf = cumsum(post{k});
            index = find(cdf - zeta > 0,1,'first');
            f_sample(k) = fs(index);
        else
            f_sample(k) = f.exp(k) + sqrt(f.variance_in_post(k))*randn;
        end

    end
        
    %% Compute intransitivity and transitivity
    [flow,ratings_sample,~,measures] = Perform_HHD(f_sample,G,complete_flag,nan);
    
    f_con_sample = flow.con;
    f_rot_sample = flow.rot;
    
    intensity_sample(m) = measures.total;
    transitivity_sample(m) = measures.trans;
    transitivity_rel_sample(m) = measures.trans/measures.total;
    intransitivity_sample(m) = measures.intrans;
    intransitivity_rel_sample(m) = measures.intrans/measures.total;
    rho_sample(m) = measures.rho;
    
    %% add to empirical distribution for potential of each competitor
    ratings_samples(:,m) = ratings_sample;
    
    %% Store sampled forces (rotational, conservative, and combined) 
    f_samples.full(:,m) = f_sample;
    f_samples.con(:,m) = f_con_sample;
    f_samples.rot(:,m) = f_rot_sample;
    
    %% compute ranking
    [~,rank] = sort(ratings_sample,'descend');
    rank_samples(:,m) = rank';
    
    %% output update on number of samples complete
    msg = sprintf('Sampling %d Percent Complete', round(100*m/n_real));
    if m > 1
        fprintf([reverseStr, msg])
    else
        fprintf(msg)
    end
    reverseStr = repmat(sprintf('\b'), 1, length(msg));

    
end
msg = sprintf('Sampling Complete, Analyzing Samples');
fprintf([reverseStr, msg])
reverseStr = repmat(sprintf('\b'), 1, length(msg));

%% collate distribution of marginal distributions for measures
edges = linspace(f_range(1),f_range(2),max(round(n_real/100),100));
[transitivity.dist,transitivity.edges] = histcounts(transitivity_sample,edges,'Normalization','probability');
[transitivity.rel.dist,transitivity.rel.edges] = histcounts(transitivity_rel_sample,edges,'Normalization','probability');
[intransitivity.dist,intransitivity.edges] = histcounts(intransitivity_sample,edges,'Normalization','probability');
[intransitivity.rel.dist,intransitivity.rel.edges] = histcounts(intransitivity_rel_sample,edges,'Normalization','probability');


%% Compute expected intransitivity (absolute and relative) and meta statistics
intransitivity.expected = mean(intransitivity_sample);
intransitivity.variance = var(intransitivity_sample);
intransitivity.rel.expected = mean(intransitivity_rel_sample);
intransitivity.rel.variance = var(intransitivity_rel_sample);

transitivity.expected = mean(transitivity_sample);
transitivity.variance = var(transitivity_sample);
transitivity.rel.expected = mean(transitivity_rel_sample);
transitivity.rel.variance = var(transitivity_rel_sample);

rho.expected = mean(rho_sample);
rho.variance = var(rho_sample);



%% Compute upper threshold and lower threshold on 95% probability of intransitivity in region

[~,order] = sort(intransitivity_sample,'ascend');
boundary_index = floor((1 - confidence)*n_real);
intransitivity.lower = intransitivity_sample(order(boundary_index));
boundary_index = ceil(confidence*n_real);
intransitivity.upper = intransitivity_sample(order(boundary_index));


boundary_index = floor((1 - confidence)*n_real);
intransitivity.rel.lower = intransitivity_rel_sample(order(boundary_index));
boundary_index = ceil(confidence*n_real);
intransitivity.rel.upper = intransitivity_rel_sample(order(boundary_index));


%% Compute upper threshold and lower threshold on 95% probability of transitivity in region

[~,order] = sort(transitivity_sample,'ascend');
boundary_index = floor((1 - confidence)*n_real);
transitivity.lower = transitivity_sample(order(boundary_index));
boundary_index = ceil(confidence*n_real);
transitivity.upper = transitivity_sample(order(boundary_index));


boundary_index = floor((1 - confidence)*n_real);
transitivity.rel.lower = transitivity_rel_sample(order(boundary_index));
boundary_index = ceil(confidence*n_real);
transitivity.rel.upper = transitivity_rel_sample(order(boundary_index));

%% Compute upper threshold and lower threshold on 95% probability of rho in region
[~,order] = sort(rho_sample,'ascend');
boundary_index = floor((1 - confidence)*n_real);
rho.lower = rho_sample(order(boundary_index));
boundary_index = ceil(confidence*n_real);
rho.upper = rho_sample(order(boundary_index));


%% compute expected ratings and variance in ratings from rating samples
ratings.mean = mean(ratings_samples,2);
ratings.var = var(ratings_samples,[],2);


%% Approximate posterior distribution for each rating from sample
rating_bins = linspace(-3*max(abs(ratings.mean)),3*max(abs(ratings.mean)),40);
for j = 1:V
    [ratings.dist(j,:),ratings.edges(j,:)] = histcounts(ratings_samples(j,:),rating_bins,'Normalization','probability');
end

%% Compute rank distribution for each competitor
ranking.dist = zeros([V,V]);
for j = 1:V
    ranking.dist(j,:) = histcounts(rank_samples(j,:),(0.5:V+0.5),'Normalization','probability');
end


%% Compute average Spearman rank correlation, and Kendall tau between pairs of sampled rankings
ranking.correlation.Spearman = mean((sum(corr(rank_samples(:,(1:min(10^4,n_real))),...
    'Type','Spearman'))-1)/(min(10^4,n_real)-1));
ranking.correlation.Kendall = mean((sum(corr(rank_samples(:,(1:min(10^3,n_real))),...
    'Type','Kendall'))-1)/(min(10^3,n_real)-1));


%% finish
fprintf(reverseStr)

end