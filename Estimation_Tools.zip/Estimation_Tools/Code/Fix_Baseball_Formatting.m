%% fix baseball formatting
filename = '..\Data\Unformatted\Baseball\AL_Wins_2018.txt';
fid = fopen(filename);
data = textscan(fid,'%s');
fclose(fid);

n_team = round(sqrt(length(data{1,1})));
Wins = nan([n_team,n_team]);
Games = nan([n_team,n_team]);
for j = 1:n_team^2
    entry = data{1,1}(j);
    if strcmp(entry,'NaN') ~= 1
        delimeter = strfind(entry,'-');
        delimeter = delimeter{1};
        wins = str2num(entry{1});
%         wins = str2num(entry{1}(1:delimeter-1));
%         losses = str2num(entry{1}(delimeter+1:end));
        Wins(j) = wins;
%         Games(j) = wins + losses;
    end
end


