function [plausibility,f_opt] = Compute_Plausibility(wins,events,gamma,f_0,n_real,constraint_type,bound,G)
% returns the plausibility of the mle estimator for the data given a
% constraint on the class of models. Measures plausibility by estimating
% the probability of observing a set of wins given the mle model that is
% equally or more surprising to the observed set of wins.

% inputs:
% 1. wins should be a column vector with as many entries as there are pairs
% 2. events should be a column vector with as many entries as there are
% pairs
% 3. gamma should be a positive scalar (suggested gamma = 1)

% 4. f_0 is initial iterate for optimizer
% 5. n_real is number of realizations to use in Monte Carlo

% 6. constraint_type: this specifies the constraint
% allowable constraints are:
% 1. 'absolute intransitivity lower'
% 2. 'absolute intransitivity upper'
% 3. 'absolute transitivity lower'
% 4. 'absolute transitivity upper'
% 5. 'relative intransitivity lower'
% 6. 'relative intransitivity upper'
% 7. 'forcing lower'
% 8. 'forcing upper'

% 7. bound: should be a scalar, sets the boundary value for the
% constraint

% 8. G: the gradient operator (essential for computing the constraints)


%% read constraint type
if strcmp(constraint_type,'absolute intransitivity lower')
    constraint_mode = 1;
    lower_or_upper = 1;
elseif strcmp(constraint_type,'absolute intransitivity upper')
    constraint_mode = 1;
    lower_or_upper = 2;
elseif strcmp(constraint_type,'absolute transitivity lower')
    constraint_mode = 2;
    lower_or_upper = 1;
elseif strcmp(constraint_type,'absolute transitivity upper')
    constraint_mode = 2;
    lower_or_upper = 2;
elseif strcmp(constraint_type,'relative intransitivity lower')
    constraint_mode = 3;
    lower_or_upper = 1;
elseif strcmp(constraint_type,'relative intransitivity upper')
    constraint_mode = 3;
    lower_or_upper = 2;
elseif strcmp(constraint_type,'forcing lower')
    constraint_mode = 4;
    lower_or_upper = 1;
elseif strcmp(constraint_type,'forcing upper')
    constraint_mode = 4;
    lower_or_upper = 2;
end

%% Save constraint type, bound, and gradient operator
% save('constraint_to_enforce','constraint_mode','lower_or_upper','bound','G')

%% Define objective function
% define loss function (negative log likelihood)
loss_function = @(x) sum((wins + gamma).*log(1 + exp(-2*x)) + (events - wins + gamma).*log(1 + exp(2*x)));

%% Perform constrained minimization
options = optimoptions(@fmincon,'Algorithm','sqp','Display','none'); % sets the correct constrained optimization method
f_opt = fmincon(loss_function,f_0,[],[],[],[],[],[],...
    @(x)constraint_function(x,constraint_mode,lower_or_upper,bound,G),options);

%% Get optimal win probabilities
p_opt = (1 + exp(-2*f_opt)).^(-1);

%% compute log likelihood of actual data from optimal model
log_likelihood_observed = sum(log(binopdf(wins,events,p_opt)));

%% Evaluate plausibility by Monte Carlo
E = length(wins);

wins_sample = zeros([E,n_real]);
for k = 1:E
    % sample a set of wins given the optimal model
    wins_sample(k,:) = binornd(events(k),p_opt(k),[1,n_real]);
end

count_more_surprising = 0;
for j = 1:n_real
    
    % compute likelihood of sample
    log_likelihood_sample = sum(log(binopdf(wins_sample(:,j),events,p_opt)));
    
    % record number of sampled wins that are more surprising than actual
    % data
    if log_likelihood_sample <= log_likelihood_observed
        count_more_surprising = count_more_surprising + 1;
    end
        
end

plausibility = count_more_surprising/n_real;


end






%% Define constraint function
function [c,ceq] = constraint_function(x,constraint_mode,lower_or_upper,bound,G)
%% read constraint conditions
% load('constraint_to_enforce')

%% compute ratings
L = G'*G;
div = G'*x;
phi = [0;L((2:end),(2:end))\div(2:end)];

%% define constraint
if constraint_mode == 1
    f_intransitive = x - G*phi;

    c = norm(f_intransitive) - bound;
    if lower_or_upper == 2
        c = -c; % default is to look for where c <= 0, this corresponds to norm <= bound, so
        % for the upper bound use -c, then looking for c >= 0, so norm >=
        % bound
    end
    ceq = [];
 
    
elseif constraint_mode == 2
    f_transitive = G*phi;
    c = norm(f_transitive) - bound;
    if lower_or_upper == 2
        c = -c; % default is to look for where c <= 0, this corresponds to norm <= bound, so
        % for the upper bound use -c, then looking for c >= 0, so norm >=
        % bound
    end
    ceq = [];

    
elseif constraint_mode == 3
    f_intransitive = x - G*phi;

    c = norm(f_intransitive)/norm(x) - bound;
    if lower_or_upper == 2
        c = -c; % default is to look for where c <= 0, this corresponds to norm <= bound, so
        % for the upper bound use -c, then looking for c >= 0, so norm >=
        % bound
    end
    ceq = [];

    
elseif constraint_mode == 4
   f = x;

   c = norm(f) - bound;
   if lower_or_upper == 2
       c = -c; % default is to look for where c <= 0, this corresponds to norm <= bound, so
       % for the upper bound use -c, then looking for c >= 0, so norm >=
       % bound
   end
   ceq = [];

end

    
end