function [model] = Test_Hypothesis(hypothesis,V,E,gamma,wins,events,G,f_mle,ratings_mle)
% evaluate how well it explains the data by computing the probability of
% having observed the data given the model, the probability of having
% observed a data set with lower probability than the data we did observe

%% define likelihood function
% each event is independent so it is the sum of the log likelihood
% functions for each ij pair, these are each of the form 

% define loss function (negative log likelihood)
loss_function = @(x) sum((wins + gamma).*log(1 + exp(-2*x)) + (events - wins + gamma).*log(1 + exp(2*x)));
if strcmp(hypothesis,'perfectly transitive') == 1
    loss_function_transitive = @(u) loss_function(G*u);
end

%% optimize 
options = optimoptions(@fmincon,'Display','none');
if strcmp(hypothesis,'perfectly transitive') == 1
    % perfectly transitive
    u_optimal = fmincon(loss_function_transitive,ratings_mle,[],[],ones([1,V]),0,[],[],[],options);
    f_optimal = G*u_optimal; % optimal flow
elseif strcmp(hypothesis,'perfectly cyclic') == 1
    % perfectly cyclic
    options = optimoptions(@fmincon,'Display','none');
    warning_id = 'MATLAB:nearlySingularMatrix';
    warning('off',warning_id)
    f_optimal = fmincon(loss_function,f_mle,[],[],G',zeros([V,1]),[],[],[],options);
    warning('on',warning_id)
else
    % unconstrained use mle solution
    f_optimal = f_mle;
    u_optimal = ratings_mle;
end

p_optimal = (1 + exp(-2*f_optimal)).^(-1); % optimal win probabilities

%% find log likelihood at minimum and AIC
log_likelihood_optimal = -loss_function(f_optimal);


if strcmp(hypothesis,'perfectly transitive') == 1
    AIC = 2*(V - 1 - log_likelihood_optimal);
elseif strcmp(hypothesis,'perfectly cyclic') == 1
    AIC = 2*((E - (V - 1)) - log_likelihood_optimal);
else
    AIC = 2*(E - log_likelihood_optimal);
end

%% find probability of having observed the true data on each edge given the optimal
% win probabilities
for k = 1:E
    prob_data_given_model.prob(k) = binopdf(wins(k),events(k),p_optimal(k));
end

%% one sided p for each edge
% find probability if randomly sample from optimal conservative model that
% we would draw a set of wins with probability smaller than the probability
% of the data given the model AND all the errors in the same direction
for k = 1:E
    if wins(k)/events(k) < p_optimal(k)
        prob_data_given_model.p_one_sided(k) = binocdf(wins(k),events(k),p_optimal(k));
    else
        prob_data_given_model.p_one_sided(k) = 1 - binocdf(wins(k),events(k),p_optimal(k));
    end
end

%% two sided p for each edge
% find probability if randomly sample from optimal conservative model that
% we would draw a set of wins with probability smaller than the probability
% of the data given the model 
for k = 1:E
    if wins(k)/events(k) < p_optimal(k)
        w = floor(p_optimal(k)*events(k));
        stop = 0;
        while stop == 0
            w = w+1;
            prob = binopdf(w,events(k),p_optimal(k));
            if prob <= prob_data_given_model.prob(k)
                stop = 1;
            end
        end
        prob_data_given_model.p_two_sided(k) =...
            binocdf(wins(k),events(k),p_optimal(k)) + (1 - binocdf(w,events(k),p_optimal(k)));
    else
        w = ceil(p_optimal(k)*events(k));
        stop = 0;
        while stop == 0
            w = w-1;
            prob = binopdf(w,events(k),p_optimal(k));
            if prob <= prob_data_given_model.prob(k)
                stop = 1;
            end
        end
        prob_data_given_model.p_two_sided(k) =...
            binocdf(w,events(k),p_optimal(k)) + (1 - binocdf(wins(k),events(k),p_optimal(k)));
    end
end

%% Percent edges in confidence interval
% find 50% and 95% confidence intervals for win frequencies given optimal
% conservative model (smallest sets containing 50% or 95% probability)
% compute percent of observed win frequencies that fall into 50% and 95%
% confidence intervals for win frequencies given optimal conservative model
for k = 1:E
    win_freq_prob = binopdf((0:events(k)),events(k),p_optimal(k));
    [~,probability_order] = sort(win_freq_prob,'descend');
    stop = 0;
    prob = 0;
    j = 0;
    while stop == 0
        j = j+1;
        prob = prob + win_freq_prob(probability_order(j));
        if prob >= 0.5
            fifty_percent_threshold = j;
            stop = 1;
        end
    end
    
    stop = 0;
    prob = 0;
    j = 0;
    while stop == 0
        j = j+1;
        prob = prob + win_freq_prob(probability_order(j));
        if prob >= 0.95
            ninety_five_percent_threshold = j;
            stop = 1;
        end
    end
    
    fifty_percent.lower(k) = (min(probability_order((1:fifty_percent_threshold)))-1)/events(k);
    fifty_percent.upper(k) = (max(probability_order((1:fifty_percent_threshold)))-1)/events(k);
    
    ninety_five_percent.lower(k) = (min(probability_order((1:ninety_five_percent_threshold))-1)/events(k));
    ninety_five_percent.upper(k) = (max(probability_order((1:ninety_five_percent_threshold))-1)/events(k));

    % find if inside either interval
    if wins(k)/events(k) >= fifty_percent.lower(k) && wins(k)/events(k) <= fifty_percent.upper(k)
        prob_data_given_model.within_fifty_percent(k) = 1;
    else
        prob_data_given_model.within_fifty_percent(k) = 0;
    end
    
    if wins(k)/events(k) >= ninety_five_percent.lower(k) && wins(k)/events(k) <= ninety_five_percent.upper(k)
        prob_data_given_model.within_ninety_five_percent(k) = 1;
    else
        prob_data_given_model.within_ninety_five_percent(k) = 0;
    end
    
end

prob_data_given_model.percent_in_fifty = ...
    sum(prob_data_given_model.within_fifty_percent)/(E);
prob_data_given_model.percent_in_ninety_five = ...
    sum(prob_data_given_model.within_ninety_five_percent)/(E);

%% compute plausibility of model by Monte Carlo

n_real = 10^4; 
wins_sample = zeros([E,n_real]);
for k = 1:E
    % sample a set of wins given the optimal model
    wins_sample(k,:) = binornd(events(k),p_optimal(k),[1,n_real]);
end

log_likelihood_observed = sum(log(binopdf(wins,events,p_optimal)));
count_more_surprising = 0;
for j = 1:n_real
    
    % compute likelihood of sample
    log_likelihood_sample = sum(log(binopdf(wins_sample(:,j),events,p_optimal)));
    
    % record number of sampled wins that are more surprising than actual
    % data
    if log_likelihood_sample <= log_likelihood_observed
        count_more_surprising = count_more_surprising + 1;
    end
    
    % output what percent complete
    msg = sprintf('Testing %d Percent Complete', round(100*j/n_real));
    if j > 1
        fprintf([reverseStr, msg])
    else
        fprintf(msg)
    end
    reverseStr = repmat(sprintf('\b'), 1, length(msg));
        
end
fprintf(reverseStr)

plausibility = count_more_surprising/n_real;

%% format output
model.optimal_flow = f_optimal;
model.optimal_p = p_optimal;
if strcmp(hypothesis,'perfectly cyclic') == 0 
    model.optimal_ratings = u_optimal;
end

model.match_to_data.log_likelihood = log_likelihood_optimal;
model.match_to_data.AIC = AIC;

model.match_to_data_per_edge.probability_observe_data_per = prob_data_given_model.prob;
model.match_to_data_per_edge.p_test_one_sided = prob_data_given_model.p_one_sided;
model.match_to_data_per_edge.p_test_two_sided = prob_data_given_model.p_two_sided;
model.match_to_data_per_edge.in_50_confidence = prob_data_given_model.within_fifty_percent;
model.match_to_data_per_edge.in_95_confidence = prob_data_given_model.within_ninety_five_percent;


model.match_to_data.percent_edges_in_50 = prob_data_given_model.percent_in_fifty;
model.match_to_data.percent_edges_in_95 = prob_data_given_model.percent_in_ninety_five;

model.confidence_int.fifty = [fifty_percent.lower',fifty_percent.upper'];
model.confidence_int.ninety_five = [ninety_five_percent.lower',ninety_five_percent.upper'];


model.match_to_data.plausibility = plausibility;

end