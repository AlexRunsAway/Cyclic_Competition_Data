function [probability,D] = Compute_posterior_probability_Condorcet(input,n_real)
%% computes posterior probability of sampling a voting record (with same number of votes 
% where a Condorcet paradox is observed in win probabilities per voter

%% extract relevant information from input
gamma = input.prior.gamma;
wins = input.data.wins;
losses = input.data.losses;

V = input.dimensions.V;
E = input.dimensions.E;

edge_to_endpoints = input.topology.edge_to_endpoints;
complete_flag = input.topology.complete_flag;

%% compute signature probabilities
p = 1 - betacdf(1/2*ones([E,1]),wins + gamma, losses + gamma); % probability of signature +1 or -1

reversed = (p < 1/2);
reversed_sign = ones([E,1]);
reversed_sign(reversed) = -1;

q = 1 - p;
p(p < 1/2) = q(p < 1/2);

%% sample signatures
zeta = rand([E,n_real]); 
signatures = sign(p*ones([1,n_real]) - zeta); % if p > zeta then +1, else -1, so equals 1 with probability p, -1 with probability 1 - p

%% loop over samples
Condorcet_count = 0;
D = zeros(V,V);
for j = 1:n_real
    %% form dominance matrix
    signature = reversed_sign.*signatures(:,j); % signature relative to edge to endpoints
        
    %% form dominance matrix
    dominance = sparse(edge_to_endpoints(signature > 0,1),edge_to_endpoints(signature > 0,2),1,V,V) + ...
        sparse(edge_to_endpoints(signature < 0,2),edge_to_endpoints(signature < 0,1),1,V,V); % when signature negative reverse dominance direction
    dominance = full(dominance);
    
    D = D + dominance;
    
    %% compute number dominated
    number_dominated = sum(dominance,2);
    
    if max(number_dominated) < V - 1
        Condorcet_count = Condorcet_count + 1;
    end
end


%% get probability
probability = Condorcet_count/n_real;
D = D/n_real;

end