function beta = Estimate_Beta(wins,events)

losses = events - wins;

negative_log_likelihood = @(beta) -(sum(gammaln(wins + beta) + gammaln(losses + beta) + ...
    - gammaln(events + 2*beta)) + length(wins)*(gammaln(2*beta) - 2*gammaln(beta)));

beta_0 = 1;

options = optimoptions(@fmincon,'Algorithm','sqp','Display','none'); % sets the correct constrained optimization method
beta = fmincon(negative_log_likelihood,beta_0,-1,0,[],[],0,10^2,[],options);

end