function [dimensions,A,adjacency_list,complete_flag,edge_to_endpoints,...
    edge_indices] = Get_Topology(Events);

%% get number of competitors
[V,~] = size(Events);
dimensions.V = V;

%% build adjacency matrix
A = Events;
A(A > 0) = 1;
for i = 1:V
    A(i,i) = 0;
end

%% build adjacency structure, edge to endpoints and endpoints to edge mappings
edge_count = 0;
edge_indices = nan(V,V);
for j = 1:V
    adjacency_list{j} = find(A(j,:) == 1);
    for k = 1:length(adjacency_list{j})
        i = adjacency_list{j}(k);
        if i > j
            edge_count = edge_count + 1;
            edge_to_endpoints(edge_count,:) = [j,i];
            
            edge_indices(i,j) = edge_count;
            edge_indices(j,i) = edge_count;
        end
    end
end

%% get number of edges
E = edge_count;
dimensions.E = E;

%% get number of loops
L = E - (V - 1);
dimensions.L = L;


%% test if complete
if E == V*(V-1)/2
    complete_flag = 1;
else
    complete_flag = 0;
end




end