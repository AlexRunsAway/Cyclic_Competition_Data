function [flow,ratings,theta,measures] = Perform_HHD(f,G,complete_flag,C)

%% extract dimensions
[E,V] = size(G);

%% compute divergence of f
div = G'*f;

%% check if complete
if complete_flag == 0
    %% form Laplacian
    L = G'*G;

    %% remove a row and column (set rating of competitor 1 to zero)
    L_trunc = L((2:end),(2:end));
    
    %% solve linear system for ratings
    u = L_trunc\div(2:end);
    ratings = [0;u];
    ratings = ratings - sum(ratings)/V;

    
    %% compute components of flow
    flow.con = G*ratings;
    flow.rot = f - flow.con;
    
    %% set theta to nan
    theta = nan;

else
    
    %% compute ratings
    ratings = (1/V)*div;

    %% compute components of flow
    flow.con = G*ratings;
    flow.rot = f - flow.con;
    
    if isnan(C) == 0
        %% compute (most parsimonius) vorticities
        [n_triangles,~] = size(C);
        
        options = optimoptions('linprog','Display','none');
        theta_absolute = linprog(ones([2*n_triangles,1]),[],[],[C',-C'],flow.rot,...
            zeros([2*n_triangles,1]),[],[],options); % uses linear programming to solve for solution to C' theta = f.rot that minimizes ||theta||_1
        
        theta = theta_absolute(1:n_triangles) - theta_absolute(n_triangles + 1:end);
    else
        theta = nan;
    end
end

%% compute measures
measures.trans = norm(flow.con);
measures.intrans = norm(flow.rot);
measures.total = norm(f);

%% compute rho
measures.rho = (E/sum(sum(abs(G*G' - 2*eye(E)))))*((norm(div)/norm(f))^2 - 2);

end