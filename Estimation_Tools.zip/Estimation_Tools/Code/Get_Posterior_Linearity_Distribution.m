function output = Get_Posterior_Linearity_Distribution(input,n_real)
%% computes the posterior distribution for:
% 1. reversals: number of edges that might have edge flow with sign
% opposite the estimated edge flow (reports distribution of number of
% reversals, meand, median, and mode number of reversals)
% 2. linearity h (Landau): if complete reports distribution of h, mean and
% median values, and variance
% 3. probability transitive: the posterior probability that the system is
% transitive

% based on input (matches output from estimation engine), and number of
% realizations used for sampling

%% extract relevant information from input
gamma = input.prior.gamma;
wins = input.data.wins;
losses = input.data.losses;

V = input.dimensions.V;
E = input.dimensions.E;

edge_to_endpoints = input.topology.edge_to_endpoints;
complete_flag = input.topology.complete_flag;

%% compute signature probabilities
p = 1 - betacdf(1/2*ones([E,1]),wins + gamma, losses + gamma);
reversed = (p < 1/2);
reversed_sign = ones([E,1]);
reversed_sign(reversed) = -1;
q = 1 - p;
p(p < 1/2) = q(p < 1/2);

%% sample signatures
zeta = rand([E,n_real]); 
signatures = sign(p*ones([1,n_real]) - zeta); 

%% compute distribution of number of edge reversals
reversals = sum(signatures == -1);
[output.reversals.dist,~] = histcounts(reversals,(-0.5:1:E+0.5),'normalization','probability');
output.reversals.mean = mean(reversals);
output.reversals.median = median(reversals);
output.reversals.mode = mode(reversals);



%% check if complete
if complete_flag == 1
    
    %% compute normalization for linearity
    Z = (V^3 - V)/12; % note this is Landau not Kendall
    
    
    %% loop over samples
    h = zeros([1,n_real]);
    for j = 1:n_real
        signature = reversed_sign.*signatures(:,j); % signature relative to edge to endpoints
        
        %% form dominance matrix
        D = sparse(edge_to_endpoints(signature > 0,1),edge_to_endpoints(signature > 0,2),1,V,V) + ...
            sparse(edge_to_endpoints(signature < 0,2),edge_to_endpoints(signature < 0,1),1,V,V); % when signature negative reverse dominance direction
        
        %% compute linearity
        dominated = full(sum(D,2));
        
        h(j) = (1/Z)*sum((dominated - (V-1)/2).^2);
        
    end
    
    %% store distribution of linearity values, probability transitive, and mean linearity
    [output.h.dist,output.h.edges] = histcounts(h,linspace(0,1,50),'normalization','probability');
    output.h.mean = mean(h);
    output.h.median = median(h);
    output.h.std = std(h);
    
    output.p_trans = sum(h == 1)/n_real;
    
    
else
    output.h.dist = nan;
    output.h.edges = nan;
    output.h.mean = nan;
    output.h.median = nan;
    output.h.std = nan;
    
    %% loop over samples
    transitive_count = 0;
    
    for index = 1:n_real
        signature = reversed_sign.*signatures(:,index); % signature relative to edge to endpoints
        
        %% check if transitive
        transitive = 1; % start assuming transitive, look for inconsistencies
        stop = 0; % stop when find intransitivity
        k = 0; % counts over edges
        D = zeros(V,V); % stores all our ordering expectations
        while stop == 0
            k = k + 1;
            
            % get endpoints
            i = edge_to_endpoints(k,1);
            j = edge_to_endpoints(k,2);

            % check if match expectation on this pair
            i_over_j = D(i,j);
            j_over_i = D(j,i);
            if signature(k) < 0 && i_over_j > 0 % expect i beats j but see j beat i
                transitive = 0; % found an intransitivity
                stop = 1;
            elseif signature(k) > 0 && j_over_i > 0 % expect j beats i but see i beats j
                transitive = 0; % found an intransitivity
                stop = 1;
            end
            
            if stop == 0
                if signature(k) > 0 % i dominates j
                    D(i,j) = 1;
                    D(i,:) = D(i,:) + D(j,:); % if transitive, everyone j dominates should also be dominated by i
                    D(:,j) = D(:,j) + D(:,i); % if transitive, everyone dominating i also dominates j
                else % j dominates i
                    D(j,i) = 1;
                    D(j,:) = D(j,:) + D(i,:); % if transitive, everyone j dominates should also be dominated by i
                    D(:,i) = D(:,i) + D(:,j); % if transitive, everyone dominating j also dominates i
                end
            end
            
            if k == E
                stop = 1;
            end
        end
        
        transitive_count = transitive_count + transitive;
       
    end
    
    %% 
    output.p_trans = transitive_count/n_real;
    
    
end




end