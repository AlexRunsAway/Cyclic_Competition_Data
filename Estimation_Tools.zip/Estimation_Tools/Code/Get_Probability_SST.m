function prob_SST = Get_Probability_SST(input,n_real)
%% estimates the posterior probability that the Strong Stochastic Transitivity
% hypothesis is true by sampling

% SST says that if the system is transitive and i ranked above k then for
% p_{ik} > max(p_{jl}) for any i > j > l > k such that there is a path from
% i to k not including ik passing through jl

% if the graph is complete this means that, after ordering in rank order
% the matrix with entries equal to the win probabililites must satisfy p_{ij}
% greater than all p's in the matrix only including rows and columns from i
% to j

% limited to complete tournaments

%% extract relevant information from input
gamma = input.prior.gamma;
wins = input.data.wins;
losses = input.data.losses;

V = input.dimensions.V;
E = input.dimensions.E;

edge_to_endpoints = input.topology.edge_to_endpoints;
complete_flag = input.topology.complete_flag;

%% check complete
if complete_flag == 1
    
    
    %% sample probabilities
    ps = betarnd((wins + gamma).*ones([1,n_real]),(losses + gamma).*ones([1,n_real]),[E,n_real]);
    
    %% loop over samples
    SST_count = 0;
    for index = 1:n_real
        p = ps(:,index);
        P = sparse(edge_to_endpoints(:,1),edge_to_endpoints(:,2),p,V,V) + ...
            sparse(edge_to_endpoints(:,2),edge_to_endpoints(:,1),1 - p,V,V);
        P = full(P);
        
        %% compute dominance matrix
        D = round(P);
        
        
        %% check WST (transitive) by computing linearity
        Z = (V^3 - V)/12;
        dominated = full(sum(D,2));
        h = (1/Z)*sum((dominated - (V-1)/2).^2);
        if h == 1 % linear
            %% if transitive compute hierarchy
            [~,order] = sort(dominated,'descend');
            
            %% check SST and update counter
            pass = 1;
            stop = 0;
            i = 0;
            while stop == 0
                i = i + 1;
                for j = i+1:V - 1
                    k = j + 1;
                    
                    p_ij = P(order(i),order(j));
                    p_jk = P(order(j),order(k));
                    p_ik = P(order(i),order(k));
                    
                    if p_ik < max(p_ij,p_jk)
                        pass = 0;
                        stop = 1;
                    end
                    
                    if p_ik < max(P((i+1:k-1),k))
                        pass = 0;
                        stop = 1;
                    end
                end
                
                if i == V
                    stop = 1;
                end
            end
            
            SST_count = SST_count + pass;
            
        end
        
    end
    
    %% estimate probability
    prob_SST = SST_count/n_real;
    
else
    prob_SST = nan;
    
end