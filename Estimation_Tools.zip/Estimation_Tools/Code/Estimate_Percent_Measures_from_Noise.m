function percent = Estimate_Percent_Measures_from_Noise(G,f)

%% get dimensions
[E,V] = size(G);

%% get projectors
[U,~,~] = svd(full(G),0);
Q = U(:,(1:V-1));
P_trans = Q*Q';
P_cyc = eye([E,E]) - P_trans;

%% estimate percent of (squared) measures from noise
percent.total = 100*sum(f.variance_in_post)/(norm(f.exp)^2);
percent.trans = 100*sum(diag(P_trans).*f.variance_in_post)/(norm(f.con.exp)^2);
percent.intrans = 100*sum(diag(P_cyc).*f.variance_in_post)/(norm(f.rot.exp)^2);

end