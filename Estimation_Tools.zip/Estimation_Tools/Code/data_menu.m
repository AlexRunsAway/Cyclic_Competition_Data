%% INPUT MENU
function data_menu(format)
%% formatting
margin = format.margin;
font_big = format.font_big;
font_medium = format.font_medium;
font_small = format.font_small;
grey_color = format.grey_color;
button_color = format.button_color;


%% create new figure window
Input_Data_Menu = figure('Name','Data Menu','NumberTitle','off',...
    'Visible','on',...
    'Units','pixels','Position',[100,100,500,500],...
    'Color',grey_color);

Title = uicontrol('Style','Text','Visible','on',...
    'String','Data Menu: ',...
    'FontSize',font_big,...
    'BackgroundColor',grey_color,...
    'Units','normalized','Position',[0.75/2,0.94,0.25,0.05]);

%% choose between picking an example vs loading your own data
choices = {'Load My Own Data ','Use Built-In Example '};
data_filename_display = uicontrol('Style','popupmenu',...
    'Visible','on',...
    'String',choices,...
    'FontSize',font_small,'HorizontalAlignment','left',...
    'Callback',@choose_data_example_or_load,...
    'Units','normalized','Position',[margin,0.8,0.35,0.05]);

    function choose_data_example_or_load(~,~)
        mode = data_filename_display.Value;
        
        if mode == 1 % switched from 1 to 2, hide example choices, show filename input
            set(pick_example_label,'Visible','off')
            set(pick_example,'Visible','off')
            set(stock_examples_documentation,'Visible','off')
            
            set(input_filename_label,'Visible','on')
            set(input_filename,'Visible','on')
            set(file_format_label,'Visible','on')
            set(file_format_dropdown,'Visible','on')
            set(file_format_documentation,'Visible','on')
            
            % make load button invisible
            set(load_data,'Visible','off')
            
        elseif mode == 2 % switched from 2 to 1, hide example choices, show filename input
            set(input_filename_label,'Visible','off')
            set(input_filename,'Visible','off')
            set(file_format_label,'Visible','off')
            set(file_format_dropdown,'Visible','off')
            set(file_format_documentation,'Visible','off')
            
            set(pick_example_label,'Visible','on')
            set(pick_example,'Visible','on')
            set(stock_examples_documentation,'Visible','on')
            
             % make load button invisible
            set(load_data,'Visible','off')
        end
    end

%% if using user data select if already formatted
file_format_label = uicontrol('Style','Text','Visible','on',...
    'String','My data ',...
    'FontSize',font_medium,...
    'HorizontalAlignment','left',...
    'BackgroundColor',grey_color,...
    'Units','normalized','Position',[margin,0.65,0.15,0.05]);

format_choices = {'is already formatted ','needs formatting '};
file_format_dropdown = uicontrol('Style','popupmenu',...
    'Visible','on',...
    'String',format_choices,...
    'FontSize',font_small,'HorizontalAlignment','left',...
    'Callback',@file_format_callback,...
    'Units','normalized','Position',[margin + 0.125,0.652,0.35,0.05]);

    function file_format_callback(~,~)
        
        if file_format_dropdown.Value == 1
            
            % show file name enter 
            set(input_filename_label,'Visible','on')
            set(input_filename,'Visible','on')
            
            % hide file input menu
            set(filename_column_label,'Visible','off')
            set(names_label,'Visible','off')
            set(win_loss_label,'Visible','off')
            set(ties_label,'Visible','off')
            set(win_freq_label,'Visible','off')
            set(names_input,'Visible','off')
            set(win_loss_input,'Visible','off')
            set(ties_available,'Visible','off')
            set(ties_input,'Visible','off')
            set(win_freq_available,'Visible','off')
            set(win_freq_input,'Visible','off')
            set(collate_label,'Visible','off')
            set(collated_data_filename_input,'Visible','off')
            
            % hide load button
            set(load_data,'Visible','off')
            
            
        elseif file_format_dropdown.Value == 2
            
            % hide file name enter 
            set(input_filename_label,'Visible','off')
            set(input_filename,'Visible','off')
            
            % show file input menu
            set(filename_column_label,'Visible','on')
            set(names_label,'Visible','on')
            set(win_loss_label,'Visible','on')
            set(ties_label,'Visible','on')
            set(win_freq_label,'Visible','on')
            set(names_input,'Visible','on')
            set(win_loss_input,'Visible','on')
            set(ties_available,'Visible','on')
            set(win_freq_available,'Visible','on')
            
            % hide load button 
            set(load_data,'Visible','off')
            
        end 
    end

%% documentation button

file_format_documentation = uicontrol('Style','pushbutton','Visible','on',...
    'String','formatting help',...
    'FontSize',font_small,'HorizontalAlignment','center',...
    'Callback',@format_documentation_callback,...
    'BackgroundColor',button_color,...
    'Units','normalized','Position',[margin + 0.55,0.65,0.2,0.05]);

    function format_documentation_callback(~,~)
        if file_format_dropdown.Value == 1
            height = 375;
            name = 'Data Format Documentation (Collated Files)';
        elseif file_format_dropdown.Value == 2
            height = 590;
            name = 'Data Format Documentation (Seperate Files)';
        end
        format_documentation_window = figure('Name',name,...
            'NumberTitle','off',...
            'Visible','on',...
            'Units','pixels','Position',[600,600 - height,500,height],...
            'Color',grey_color);
        
        if file_format_dropdown.Value == 1
            string = textread('..\Documentation\data_format_documentation_collated.txt','%s',...
                'whitespace','');
        elseif file_format_dropdown.Value == 2
            string = textread('..\Documentation\data_format_documentation_separated.txt','%s',...
                'whitespace','');
        end
        documentation = uicontrol('Style','Text','Visible','on',...
            'String',string,...
            'FontSize',font_small,...
            'BackgroundColor',grey_color,...
            'HorizontalAlignment','left',...
            'Units','normalized','Position',[margin/2,margin/2,1-margin,1-margin]);
    end

%% if already formatted enter data
input_filename_label = uicontrol('Style','Text','Visible','on',...
    'String','Filename to Load: ',...
    'FontSize',font_medium,...
    'HorizontalAlignment','left',...
    'BackgroundColor',grey_color,...
    'Units','normalized','Position',[margin,0.5,0.25,0.05]);
input_filename = uicontrol('Style','edit',...
    'Visible','on',...
    'FontSize',font_small,'HorizontalAlignment','left',...
    'Callback',@enter_filename,...
    'Units','normalized','Position',[margin + 0.25,0.5,0.35,0.05]);

    function enter_filename(~,~) 
        % make load button visible
        set(load_data,'Visible','on')
        
    end

%% if not already formatted present menu
filename_column_label = uicontrol('Style','Text','Visible','off',...
    'String','Enter Filenames (include extension): ',...
    'FontSize',font_small,...
    'HorizontalAlignment','left',...
    'BackgroundColor',grey_color,...
    'Units','normalized','Position',[margin + 0.45,0.55,0.45,0.05]);


% enter competitor names
names_label = uicontrol('Style','Text','Visible','off',...
    'String','Competitor Names: ',...
    'FontSize',font_small,...
    'HorizontalAlignment','left',...
    'BackgroundColor',grey_color,...
    'Units','normalized','Position',[margin,0.5,0.4,0.05]);
names_input = uicontrol('Style','edit',...
    'Visible','off',...
    'FontSize',font_small,'HorizontalAlignment','left',...
    'Callback',@enter_names,...
    'Units','normalized','Position',[margin + 0.45,0.5,0.35,0.05]);
names_entered = 0;
    function enter_names(~,~)
        names_entered = 1;
        
        if names_entered == 1 && win_loss_entered == 1
            % show collate options
            set(collate_label,'Visible','on')
            set(collated_data_filename_input,'Visible','on')
        end
    end

% enter win loss data
win_loss_label = uicontrol('Style','Text','Visible','off',...
    'String','Win Data: ',...
    'FontSize',font_small,...
    'HorizontalAlignment','left',...
    'BackgroundColor',grey_color,...
    'Units','normalized','Position',[margin,0.42,0.4,0.05]);
win_loss_input = uicontrol('Style','edit',...
    'Visible','off',...
    'FontSize',font_small,'HorizontalAlignment','left',...
    'Callback',@enter_win_loss,...
    'Units','normalized','Position',[margin + 0.45,0.42,0.35,0.05]);
win_loss_entered = 0;
    function enter_win_loss(~,~)
        win_loss_entered = 1;
        
        if names_entered == 1 && win_loss_entered == 1
            % show collate options
            set(collate_label,'Visible','on')
            set(collated_data_filename_input,'Visible','on')
        end
    end


% enter tie data (optional, default to nan)
ties_label = uicontrol('Style','Text','Visible','off',...
    'String','Ties Data: ',...
    'FontSize',font_small,...
    'HorizontalAlignment','left',...
    'BackgroundColor',grey_color,...
    'Units','normalized','Position',[margin,0.34,0.4,0.05]);
ties_choices = {'None','Available'};
ties_available = uicontrol('Style','popupmenu',...
    'Visible','off',...
    'String',ties_choices,...
    'FontSize',font_small,'HorizontalAlignment','left',...
    'Callback',@ties_available_callback,...
    'Units','normalized','Position',[margin + 0.25,0.34,0.15,0.05]);
    function ties_available_callback(~,~)
        if ties_available.Value == 1
            set(ties_input,'Visible','off')
        elseif ties_available.Value == 2
            set(ties_input,'Visible','on')
        end
    end
ties_input = uicontrol('Style','edit',...
    'Visible','off',...
    'FontSize',font_small,'HorizontalAlignment','left',...
    'Units','normalized','Position',[margin + 0.45,0.34,0.35,0.05]);

% enter win frequency data (optional, default to nan)
win_freq_label = uicontrol('Style','Text','Visible','off',...
    'String','Win Freq. Data: ',...
    'FontSize',font_small,...
    'HorizontalAlignment','left',...
    'BackgroundColor',grey_color,...
    'Units','normalized','Position',[margin,0.26,0.4,0.05]);
win_freq_choices = {'None','Available'};
win_freq_available = uicontrol('Style','popupmenu',...
    'Visible','off',...
    'String',win_freq_choices,...
    'FontSize',font_small,'HorizontalAlignment','left',...
    'Callback',@win_freq_available_callback,...
    'Units','normalized','Position',[margin + 0.25,0.26,0.15,0.05]);
    function win_freq_available_callback(~,~)
        if win_freq_available.Value == 1
            set(win_freq_input,'Visible','off')
        elseif win_freq_available.Value == 2
            set(win_freq_input,'Visible','on')
        end
    end
win_freq_input = uicontrol('Style','edit',...
    'Visible','off',...
    'FontSize',font_small,'HorizontalAlignment','left',...
    'Units','normalized','Position',[margin + 0.45,0.26,0.35,0.05]);

% save as collated data + collate button
collate_label = uicontrol('Style','Text','Visible','off',...
    'String','Filename to Save Formatted Data to: ',...
    'FontSize',font_small,...
    'HorizontalAlignment','left',...
    'BackgroundColor',grey_color,...
    'Units','normalized','Position',[margin,0.178,0.45,0.05]);
collated_data_filename_input = uicontrol('Style','edit',...
    'Visible','off',...
    'FontSize',font_small,'HorizontalAlignment','left',...
    'Callback',@collate_data_callback,...
    'Units','normalized','Position',[margin + 0.45,0.18,0.35,0.05]);
    function collate_data_callback(~,~)
        % show load button
        set(load_data,'Visible','on')
    end



%% pick from stock example
pick_example_label = uicontrol('Style','Text','Visible','off',...
    'String','Pick Example: ',...
    'FontSize',font_medium,...
    'HorizontalAlignment','left',...
    'BackgroundColor',grey_color,...
    'Units','normalized','Position',[margin,0.65,0.2,0.05]);

example_choices = {'Parliamentary Polling Data ','Social Birds ','Machine Chess ','MLB '};
pick_example = uicontrol('Style','popupmenu',...
    'Visible','off',...
    'String',example_choices,...
    'FontSize',font_small,'HorizontalAlignment','left',...
    'Callback',@pick_example_callback,...
    'Units','normalized','Position',[margin + 0.2,0.65,0.4,0.05]);
    
    function pick_example_callback(~,~)
        
        % make load button visible
        set(load_data,'Visible','on')
    end

stock_examples_documentation = uicontrol('Style','pushbutton',...
    'Visible','off',...
    'String','Documentation',...
    'FontSize',font_small,'HorizontalAlignment','center',...
    'Callback',@stock_examples_documentation_callback,...
    'BackgroundColor',button_color,...
    'Units','normalized','Position',[margin + 0.65,0.655,0.2,0.05]);

    function stock_examples_documentation_callback(~,~)
        height = 525;
        
        name = 'Stock Examples Documentation';
        examples_documentation_window = figure('Name',name,...
            'NumberTitle','off',...
            'Visible','on',...
            'Units','pixels','Position',[600,600 - height,500,height],...
            'Color',grey_color);
        
            string = textread('..\Documentation\stock_examples_documentation.txt','%s',...
                'whitespace','');
            
        documentation = uicontrol('Style','Text','Visible','on',...
            'String',string,...
            'FontSize',font_small,...
            'BackgroundColor',grey_color,...
            'HorizontalAlignment','left',...
            'Units','normalized','Position',[margin/2,margin/2,1-margin,1-margin]);
    end

%% load button and error message

load_data = uicontrol('Style','pushbutton','Visible','off',...
    'String','Load Data',...
    'FontSize',font_big,'HorizontalAlignment','center',...
    'Callback',@load_data_callback,...
    'BackgroundColor',button_color,...
    'Units','normalized','Position',[margin,0.05,0.2,0.05]);

    function load_data_callback(~,~)
        %% track for errors
        error = 0;
        
        %% load file
        if data_filename_display.Value == 1
            if file_format_dropdown.Value == 1
                % files are already formatted load
                filename = input_filename.String;
                path = '..\Data\Formatted\';
                
                % check filename formatted correctly
                if isempty(filename) % no filename input
                    error = 1;
                    close all
                    fprintf('\n\n <strong> Error: </strong>')
                    fprintf('\n Data Input Incorrectly. No filename entered \n')
                else
                    if length(filename) <= 3 % no extension add .mat
                        filename = strcat(filename,'.mat');
                    else
                        if strcmp(filename(end-3:end),'.txt') % tried to save as a .txt file
                            error = 1;
                            close all
                            fprintf('\n\n <strong> Error: </strong>')
                            fprintf('\n Data Input Incorrectly. Invalid filename to save collated data to. Cannot run using a .txt \n')
                        end
                        if strcmp(filename(end-3:end),'.mat') == 0 % did not enter an extension add .mat
                            filename = strcat(filename,'.mat');
                        end
                    end
                end
                
            elseif file_format_dropdown.Value == 2
                % files are not formatted, need to collate before loading
                path = '..\Data\Unformatted\';
                
                %% load names
                names_file = names_input.String;
                if strcmp(names_file(end-3:end),'.txt') % loading from text file
                    names_file = strcat(path,names_file);
                    fid = fopen(names_file);
                    names = textscan(fid,'%s','Delimiter','\n');
                    fclose(fid);
                elseif strcmp(names_file(end-3:end),'.mat') % loading from matlab file
                    names_file = strcat(path,names_file);
                    names = load(names_file);
                else
                    error = 1;
                    close all
                    fprintf('\n\n <strong> Error: </strong>')
                    fprintf('\n Data Input Incorrectly. Competitor names file neither .mat nor .txt \n')
                end
                
                %% load win loss
                win_loss_file = win_loss_input.String;
                if strcmp(win_loss_file(end-3:end),'.txt') || strcmp(win_loss_file(end-3:end),'.mat') % loading from text file or matlab file
                    win_loss_file = strcat(path,win_loss_file);
                    win_loss_data = load(win_loss_file);
                else
                    error = 1;
                    close all
                    fprintf('\n\n <strong> Error: </strong>')
                    fprintf('\n Data Input Incorrectly. Win loss file neither .mat nor .txt \n')
                end
                
                %% load ties
                if ties_available.Value == 2
                    ties_file = ties_input.String;
                    if length(ties_file) > 3
                        if strcmp(ties_file(end-3:end),'.txt') || strcmp(ties_file(end-3:end),'.mat') % loading from text file or matlab file
                            ties_file = strcat(path,ties_file);
                            ties_data = load(ties_file);
                        else
                            error = 1;
                            close all
                            fprintf('\n\n <strong> Error: </strong>')
                            fprintf('\n Data Input Incorrectly. Ties file neither .mat nor .txt \n')
                        end
                    else
                        fprintf('\n\n <strong> Warning: </strong>')
                        fprintf('\n Data May be Input Incorrectly. Ties file not provided. \n')
                        ties_data = nan;
                    end
                else
                    ties_data = nan;
                end
                
                %% load win frequency
                if win_freq_available.Value == 2
                    win_freq_file = win_freq_input.String;
                    if length(win_freq_file) > 3
                        if strcmp(win_freq_file(end-3:end),'.txt') || strcmp(win_freq_file(end-3:end),'.mat') % loading from text file or matlab file
                            win_freq_file = strcat(path,win_freq_file);
                            win_freq_data_from_file = load(win_freq_file);
                            win_freq_data.wins = win_freq_data_from_file(:,1);
                            win_freq_data.events = win_freq_data_from_file(:,2);
                        else
                            error = 1;
                            close all
                            fprintf('\n\n <strong> Error: </strong>')
                            fprintf('\n Data Input Incorrectly. Win frequency file neither .mat nor .txt \n')
                        end
                    else
                        fprintf('\n\n <strong> Warning: </strong>')
                        fprintf('\n Data May be Input Incorrectly. Win frequency file not provided. \n')
                        win_freq_data.wins = nan;
                        win_freq_data.events = nan;
                    end
                else
                    win_freq_data.wins = nan;
                    win_freq_data.events = nan;
                end
                
                %% collate and save
                filename_to_save_to = collated_data_filename_input.String;
                if isempty(filename_to_save_to) % entered an empty filename
                    error = 1;
                    close all
                    fprintf('\n\n <strong> Error: </strong>')
                    fprintf('\n Data Input Incorrectly. Invalid filename to save collated data to. \n')
                else % entered a nonempty filename
                    if length(filename_to_save_to) <= 3 % did not enter an extension, set to .mat
                        save_name = strcat(filename_to_save_to,'.mat');
                    else % may have entered an extension
                        if strcmp(filename_to_save_to(end-3:end),'.txt') % tried to save as a .txt file
                            error = 1;
                            close all
                            fprintf('\n\n <strong> Error: </strong>')
                            fprintf('\n Data Input Incorrectly. Invalid filename to save collated data to. Cannot save to .txt \n')
                        end
                        if strcmp(filename_to_save_to(end-3:end),'.mat') == 0 % did not enter an extension add .mat
                            save_name = strcat(filename_to_save_to,'.mat');
                        else
                            save_name = filename_to_save_to; % ended in .mat, leave alone
                        end
                    end
                end
                
                %% save collated data
                if error == 0
                    path = '..\Data\Formatted\';
                    save(strcat(path,save_name),'names','win_loss_data','ties_data','win_freq_data');
                    msg = sprintf('\n Saved input data files to %s',save_name);
                    fprintf(msg)
                    
                    filename = save_name;
                end
                
            end
            
        elseif data_filename_display.Value == 2
            path = '..\Data\Formatted\';
            example_filenames = {'Polling_Example.mat','Birds_Example.mat',...
                'Chess_Example.mat','MLB_Example.mat'};
            filename = example_filenames{pick_example.Value};
        end
        
        if error == 0
            data = load(strcat(path,filename));
            msg = sprintf('\n Loaded input data from %s',filename);
            fprintf(msg)
            
            %% close data window
            pause(0.2)
            close('Data Menu')
        end
        
        
        %% Call Settings Menu
        settings_menu(format,data)
        
    end


end