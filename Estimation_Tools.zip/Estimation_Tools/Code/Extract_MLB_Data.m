function data = Extract_MLB_Data(year_range)

%% gets full win loss matrix for the entire MLB in the input range of years
% returns data.wins, data.ties and data.team_names
% does not distinguish NL from AL

% if pass a single year will only pull for that year, otherwise will pull
% for all years in range

%% read data
path = '..\Data\Unformatted\Baseball\';
fid = fopen(strcat(path,'Entire_MLB_History_to_2018_538.txt'));
history = textscan(fid,'%s','Delimiter','\n');
fclose(fid);

history = history{1};

%% preallocate for data
data.teams = {};
data.wins = [];
data.ties = [];

%% single year or many years
year_start = min(year_range);
year_end = max(year_range);

%% find entries matching the input year
stop = 0;
j = 0;
while stop == 0
    j = j+1;
    
    %% check if game was played in the correct year
    game = regexp(history{j}, '\s+','split');
    year_played = str2num(game{1});
    if year_played <= year_end && year_played >= year_start
        
        %% extract the teams who played
        team_1 = game{2};
        team_2 = game{3};
        
        %% check if we have data for these teams yet
        found_team_1 = 0;
        found_team_2 = 0;
        for k = 1:length(data.teams)
            team = data.teams{k};
            if strcmp(team_1,team) == 1
                found_team_1 = found_team_1 + 1;
                team_1_index = k;
            end
            if strcmp(team_2,team) == 1
                found_team_2 = found_team_2 + 1;
                team_2_index = k;
            end
        end
        
        if found_team_1 == 0
            data.teams{end+1} = team_1;
            team_1_index = length(data.teams);
        end
        if found_team_2 == 0
            data.teams{end+1} = team_2;
            team_2_index = length(data.teams);
        end
        
        
        %% find out who won and who lost
        score_1 = str2num(game{4});
        score_2 = str2num(game{5});
        
        if score_1 > score_2
            winner = 1;
        elseif score_1 < score_2
            winner = 2;
        else
            winner = nan;
        end
        
        %% add to win loss data
        if found_team_1 > 0 && found_team_2 > 0
            if winner == 1
                data.wins(team_1_index,team_2_index) = data.wins(team_1_index,team_2_index) + 1;
                data.wins(team_2_index,team_1_index) = data.wins(team_2_index,team_1_index);
                data.ties(team_2_index,team_1_index) = data.ties(team_2_index,team_1_index);
                data.ties(team_1_index,team_2_index) = data.ties(team_1_index,team_2_index);
            elseif winner == 2
                data.wins(team_1_index,team_2_index) = data.wins(team_1_index,team_2_index);
                data.wins(team_2_index,team_1_index) = data.wins(team_2_index,team_1_index) + 1;
                data.ties(team_2_index,team_1_index) = data.ties(team_2_index,team_1_index);
                data.ties(team_1_index,team_2_index) = data.ties(team_1_index,team_2_index);
            else
                data.wins(team_1_index,team_2_index) = data.wins(team_1_index,team_2_index);
                data.wins(team_2_index,team_1_index) = data.wins(team_2_index,team_1_index);
                data.ties(team_2_index,team_1_index) = data.wins(team_2_index,team_1_index) + 1;
                data.ties(team_1_index,team_2_index) = data.wins(team_1_index,team_2_index) + 1;
            end
        else
            if winner == 1
                data.wins(team_1_index,team_2_index) = 1;
                data.wins(team_2_index,team_1_index) = 0;
                data.ties(team_2_index,team_1_index) = 0;
                data.ties(team_1_index,team_2_index) = 0;
            elseif winner == 2
                data.wins(team_1_index,team_2_index) = 0;
                data.wins(team_2_index,team_1_index) = 1;
                data.ties(team_2_index,team_1_index) = 0;
                data.ties(team_1_index,team_2_index) = 0;
            else
                data.wins(team_1_index,team_2_index) = 0;
                data.wins(team_2_index,team_1_index) = 0;
                data.ties(team_2_index,team_1_index) = 1;
                data.ties(team_1_index,team_2_index) = 1;
            end
        end
        
    elseif year_played < year_start
        %% all other games are in the past can stop search
        stop = 1;
    end
end

%% resort alphabetically
[data.teams,order] = sort(data.teams);
data.wins = data.wins(order,order);
data.ties = data.ties(order,order);

%% get win frequency data
events = data.wins + data.wins';

data.win_freq.wins = reshape(data.wins,[size(data.wins,1)^2,1]);
data.win_freq.events = reshape(events,[size(events,1)^2,1]);

data.win_freq.wins(data.win_freq.wins == nan) = [];
data.win_freq.events(data.win_freq.events == nan) = [];
data.win_freq.wins(data.win_freq.events == 0) = [];
data.win_freq.events(data.win_freq.events == 0) = [];

end