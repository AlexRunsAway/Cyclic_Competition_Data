function Plot_Results(input)

%% read display settings
display_settings = input.input.settings.display;

%% delete all existing figures
close all

%% display win frequencies histogram and prior

% get data to plot
if input.input.settings.assumptions.use_outside_win_freq == 0
    win_frequencies = input.data.win_frequencies; % use win-loss data
    win_frequencies = [win_frequencies;1 - win_frequencies];
else
    win_frequencies = input.input.data.win_freq; % use win frequency from other data set
    win_frequencies = [win_frequencies.wins./win_frequencies.events;...
        1 - win_frequencies.wins./win_frequencies.events];
end

beta = input.prior.beta;

% plot
win_frequencies_fig = figure('Name','Win Frequencies and Prior','NumberTitle','off');
clf;
hold on
grid on
n_bins = 20;
hist(win_frequencies,n_bins)
plot((0:0.01:1),length(win_frequencies)*betapdf((0:0.01:1),beta,beta)/n_bins,'r-','Linewidth',2)
set(gca,'FontSize',16)
xlabel('Win Frequency ','FontSize',18,'interpreter','latex')
ylabel('Numer of Observations ','FontSize',18,'interpreter','latex')
title('Win Frequencies and Prior ','FontSize',18,'interpreter','latex')
l = legend('Data','Prior');
set(l,'FontSize',16,'location','northeast','interpreter','latex')

%% display posterior for edge flow and point estimators

% get data for plot
f = input.f;
E = input.dimensions.E;

% plot
flow_fig = figure('Name','Edge Flow','NumberTitle','off');
clf
hold on
grid on
errorbar((1:E),f.exp,sqrt(f.variance_in_post),'Linestyle','none','Color','k',...
    'Linewidth',1.5)
scatter((1:E),f.exp,40,'b','o','Linewidth',1.5)
scatter((1:E),f.mle,40,'r','x','Linewidth',1.5)
axis tight
set(gca,'FontSize',16)
xlabel('Edge Index ','FontSize',18,'interpreter','latex')
ylabel('Edge Flow (log-odds of victory) ','FontSize',18,'interpreter','latex')
title('Edge Flow Estimates ','FontSize',18,'interpreter','latex')
l = legend('Standard Deviation','Expectation','MAP');
set(l,'FontSize',16,'location','northeast','interpreter','latex')




%% display hodge ratings bar graph

% get data
ratings = input.rating;
ranks = input.ranking;
names = input.input.names;
V = input.dimensions.V;

% plot
ratings_bar_plot = figure('Name','Ratings','NumberTitle','off');
clf;
hold on
grid on
bar((1:V),[ratings.exp(ranks.mle),ratings.mle(ranks.mle)])
set(gca,'FontSize',14)
set(gca,'XTick',(1:V),'XTickLabel',names{1}(ranks.mle))
xtickangle(20)
xlabel('Competitors ','FontSize',18,'interpreter','latex')
ylabel('Ratings ','FontSize',18,'interpreter','latex')
title('Hodge Rating of Competitors ','FontSize',18,'interpreter','latex')


% add error bars
if input.input.settings.sampling.on_off == 1
    errorbar((1:V),ratings.exp(ranks.mle),sqrt(ratings.sampled.post.var),'Linestyle','none',...
        'Color','k','Linewidth',1.5)
    l = legend('Expected ','MAP ','STD in Posterior');
else
    l = legend('Expected ','MAP ');
end


set(l,'FontSize',18,'Location','northeast','interpreter','latex')



%% display rotational edge flow
% get data to plot
V = input.dimensions.V;
E = input.dimensions.E;
endpoints = input.topology.edge_to_endpoints;
names = input.input.names;
f = input.f;

% plot
rotational_flow_plot = figure('Name','Cyclic Flow','NumberTitle','off');
clf

subplot(1,2,1)
hold on
scatter(cos(2*pi*(1:V)/(V)),sin(2*pi*(1:V)/(V)),20,'k','fill')
text(1.2*cos(2*pi*(1:V)/(V)),1.2*sin(2*pi*(1:V)/(V)),...
    names{1},'FontSize',10,'HorizontalAlignment','center','interpreter','latex')
axis square
for k = 1:E
    flow = f.rot.mle(k);
    w = abs(flow)/max(abs(f.rot.mle));
    if flow > 0
        start = endpoints(k,1);
        finish = endpoints(k,2);
        quiver(cos(2*pi*start/(V)),sin(2*pi*start/(V)),...
            cos(2*pi*finish/(V)) - cos(2*pi*start/(V)),...
            sin(2*pi*finish/(V)) - sin(2*pi*start/(V)),...
            0,'Linewidth',0.5+round(4*w)/4,'color',[1 - w,1 - w,1 - w])
    elseif flow < 0
        start = endpoints(k,2);
        finish = endpoints(k,1);
        quiver(cos(2*pi*start/(V)),sin(2*pi*start/(V)),...
            cos(2*pi*finish/(V)) - cos(2*pi*start/(V)),...
            sin(2*pi*finish/(V)) - sin(2*pi*start/(V)),...
            0,'Linewidth',0.5+round(4*w)/4,'color',[1 - w,1 - w,1 - w])
    end
end
axis square
xlim([-1.3,1.3])
ylim([-1.3,1.3])
set(gca,'xtick',[])
set(gca,'ytick',[]);
title('MAP Cyclic Flow ','FontSize',18,'interpreter','latex')


subplot(1,2,2)
hold on
scatter(cos(2*pi*(1:V)/(V)),sin(2*pi*(1:V)/(V)),20,'k','fill')
text(1.2*cos(2*pi*(1:V)/(V)),1.2*sin(2*pi*(1:V)/(V)),...
    names{1},'FontSize',10,'HorizontalAlignment','center','interpreter','latex')
axis square
for k = 1:E
    flow = f.rot.exp(k);
    w = abs(flow)/max(abs(f.rot.exp));
    if flow > 0
        start = endpoints(k,1);
        finish = endpoints(k,2);
        quiver(cos(2*pi*start/(V)),sin(2*pi*start/(V)),...
            cos(2*pi*finish/(V)) - cos(2*pi*start/(V)),...
            sin(2*pi*finish/(V)) - sin(2*pi*start/(V)),...
            0,'Linewidth',0.5+round(4*w)/4,'color',[1 - w,1 - w,1 - w])
    elseif flow < 0
        start = endpoints(k,2);
        finish = endpoints(k,1);
        quiver(cos(2*pi*start/(V)),sin(2*pi*start/(V)),...
            cos(2*pi*finish/(V)) - cos(2*pi*start/(V)),...
            sin(2*pi*finish/(V)) - sin(2*pi*start/(V)),...
            0,'Linewidth',0.5+round(4*w)/4,'color',[1 - w,1 - w,1 - w])
    end
end
axis square
xlim([-1.3,1.3])
ylim([-1.3,1.3])
set(gca,'xtick',[])
set(gca,'ytick',[]);
title('Expected Cyclic Flow ','FontSize',18,'interpreter','latex')



%% display vorticity/curl
if input.topology.complete_flag == 1
    % get data
    L = input.dimensions.L;
    vorticity = input.vorticity;
    [~,loop_order.exp] = sort(vorticity.exp,'descend');
    [~,loop_order.mle] = sort(vorticity.mle,'descend');
    curl_implicit = input.operators.cycles;
    n_triangles = V*(V-1)*(V-2)/6; % number of triangles if complete
    
    
    % plot
    vorticities_plot_exp = figure('Name','Expected Vorticities','NumberTitle','off');
    clf

    for j = 1:min(6,L)
        subplot(2,3,j)
        hold on
        scatter(cos(2*pi*(1:V)/(V)),sin(2*pi*(1:V)/(V)),20,'k','fill')
        text(1.2*cos(2*pi*(1:V)/(V)),1.2*sin(2*pi*(1:V)/(V)),...
            names{1},'FontSize',10,'HorizontalAlignment','center')
        
        loop_index = loop_order.exp(j);
        text(0,0,num2str(vorticity.exp(loop_index),3),'FontSize',10,'HorizontalAlignment','center')
        
        if loop_index <= n_triangles % loop in forward direction
            edges = curl_implicit(loop_index,:);
            for k = 1:3
                edge = edges(k);
                if k < 3
                    start = endpoints(edge,1);
                    finish = endpoints(edge,2);
                elseif k == 3
                    start = endpoints(edge,2);
                    finish = endpoints(edge,1);
                end
                quiver(cos(2*pi*start/(V)),sin(2*pi*start/(V)),...
                    cos(2*pi*finish/(V)) - cos(2*pi*start/(V)),...
                    sin(2*pi*finish/(V)) - sin(2*pi*start/(V)),...
                    0,'Linewidth',2)
            end
        else % loop in reverse direction
            edges = curl_implicit(loop_index - n_triangles,:);
            for k = 1:3
                edge = edges(k);
                if k < 3
                    start = endpoints(edge,2);
                    finish = endpoints(edge,1);
                elseif k == 3
                    start = endpoints(edge,1);
                    finish = endpoints(edge,2);
                end
                quiver(cos(2*pi*start/(V)),sin(2*pi*start/(V)),...
                    cos(2*pi*finish/(V)) - cos(2*pi*start/(V)),...
                    sin(2*pi*finish/(V)) - sin(2*pi*start/(V)),...
                    0,'Linewidth',2)
            end
        end
        axis square
        xlim([-1.3,1.3])
        ylim([-1.3,1.3])
        set(gca,'xticklabel','','yticklabel','')
        set(gca,'xtick',[])
        set(gca,'ytick',[]);
        
        if j == 2
            title('6 Largest Vorticities (Expected Flow) ','FontSize',18,'interpreter','latex')       
        end
    end
    
    
    % plot
    vorticities_plot_map = figure('Name','MAP Vorticities','NumberTitle','off');
    clf

    for j = 1:min(6,L)
        subplot(2,3,j)
        hold on
        scatter(cos(2*pi*(1:V)/(V)),sin(2*pi*(1:V)/(V)),20,'k','fill')
        text(1.2*cos(2*pi*(1:V)/(V)),1.2*sin(2*pi*(1:V)/(V)),...
            names{1},'FontSize',10,'HorizontalAlignment','center')
        
        loop_index = loop_order.mle(j);
        text(0,0,num2str(vorticity.mle(loop_index),3),'FontSize',10,'HorizontalAlignment','center')
        
        if loop_index <= n_triangles % loop in forward direction
            edges = curl_implicit(loop_index,:);
            for k = 1:3
                edge = edges(k);
                if k < 3
                    start = endpoints(edge,1);
                    finish = endpoints(edge,2);
                elseif k == 3
                    start = endpoints(edge,2);
                    finish = endpoints(edge,1);
                end
                quiver(cos(2*pi*start/(V)),sin(2*pi*start/(V)),...
                    cos(2*pi*finish/(V)) - cos(2*pi*start/(V)),...
                    sin(2*pi*finish/(V)) - sin(2*pi*start/(V)),...
                    0,'Linewidth',2)
            end
        else % loop in reverse direction
            edges = curl_implicit(loop_index - n_triangles,:);
            for k = 1:3
                edge = edges(k);
                if k < 3
                    start = endpoints(edge,2);
                    finish = endpoints(edge,1);
                elseif k == 3
                    start = endpoints(edge,1);
                    finish = endpoints(edge,2);
                end
                quiver(cos(2*pi*start/(V)),sin(2*pi*start/(V)),...
                    cos(2*pi*finish/(V)) - cos(2*pi*start/(V)),...
                    sin(2*pi*finish/(V)) - sin(2*pi*start/(V)),...
                    0,'Linewidth',2)
            end
        end
        axis square
        xlim([-1.3,1.3])
        ylim([-1.3,1.3])
        set(gca,'xticklabel','','yticklabel','')
        set(gca,'xtick',[])
        set(gca,'ytick',[]);
        
        if j == 2
            title('6 Largest Vorticities (MAP Flow) ','FontSize',18,'interpreter','latex')       
        end
    end

end

%% display 10 strongest edges (overall, transitive, and cyclic) bar plot with decomposition

% get data
f = input.f;
var = f.variance_in_post;
E = input.dimensions.E;
G = input.operators.gradient;
Laplacian = full(G'*G); % SLOW want to work with as a sparse matrix
P_trans = G*pinv(Laplacian)*G'; % likely SLOW should modify
P_cyc = eye(E,E) - P_trans;
Sigma_trans = P_trans*diag(var)*P_trans;
Sigma_cyc = P_cyc*diag(var)*P_cyc;
var_trans = diag(Sigma_trans);
var_cyc = diag(Sigma_cyc);
endpoints = input.topology.edge_to_endpoints;
names = input.input.names;



% plot: sorted by overall
[~,flow_ranks] = sort(abs(f.exp),'descend');
Bar_Data = [abs(f.exp(flow_ranks(1:min(10,E)))),...
    sign(f.exp(flow_ranks(1:min(10,E)))).*f.con.exp(flow_ranks(1:min(10,E))),...
    sign(f.exp(flow_ranks(1:min(10,E)))).*f.rot.exp(flow_ranks(1:min(10,E)))];
Bar_Error = sqrt([var(flow_ranks(1:min(10,E))),...
    var_trans(flow_ranks(1:min(10,E))),...
    var_cyc(flow_ranks(1:min(10,E)))]);


ten_largest_flow = figure('Name','Large Edge Flows','NumberTitle','off');
clf
flow_bar_plot = bar(Bar_Data,'BarWidth',1);
grid on
axis tight

competitor_string = cell([1,1]);
for j = 1:min(10,E)
    edge = flow_ranks(j);
    if f.exp(edge) > 0
        start = endpoints(edge,1);
        finish = endpoints(edge,2);
    else
        start = endpoints(edge,2);
        finish = endpoints(edge,1);
    end
    winner = names{1}(start);
    loser = names{1}(finish);
    
    competitor_string{1}(j) = strcat(winner, ' > ', {' '}, loser);
end

set(gca,'XTick',(1:min(10,E)),'XTickLabel',competitor_string{1})
set(gca,'FontSize',12)
xtickangle(15)

ylabel('Flow ','FontSize',18,'interpreter','latex')
xlabel('Competitor Pairs ','FontSize',18,'interpreter','latex')
title('Ten Strongest Flows ','FontSize',18,'interpreter','latex')


groupwidth = min(0.8, 3/(3 + 1.5));
for i = 1:3
    % Calculate center of each bar
    x = (1:min(10,E)) - groupwidth/2 + (2*i-1) * groupwidth / (2*3);
    hold on
    errorbar(x, Bar_Data(:,i), Bar_Error(:,i),'k','LineWidth',1.5, 'linestyle', 'none');
end
l = legend('$f$','$f_{trans}$','$f_{cyc}$');
set(l,'Location','Best','FontSize',16,'Orientation','horizontal','interpreter','latex')


% sorted by transitive
[~,flow_ranks] = sort(abs(f.con.exp),'descend');
Bar_Data = [abs(f.exp(flow_ranks(1:min(10,E)))),...
    sign(f.exp(flow_ranks(1:min(10,E)))).*f.con.exp(flow_ranks(1:min(10,E))),...
    sign(f.exp(flow_ranks(1:min(10,E)))).*f.rot.exp(flow_ranks(1:min(10,E)))];
Bar_Error = sqrt([var(flow_ranks(1:min(10,E))),...
    var_trans(flow_ranks(1:min(10,E))),...
    var_cyc(flow_ranks(1:min(10,E)))]);


ten_largest_transitive_flow = figure('Name','Large Transitive Edge Flows','NumberTitle','off');
clf
flow_bar_plot = bar(Bar_Data,'BarWidth',1);
grid on
axis tight

competitor_string = cell([1,1]);
for j = 1:min(10,E)
    edge = flow_ranks(j);
    if f.exp(edge) > 0
        start = endpoints(edge,1);
        finish = endpoints(edge,2);
    else
        start = endpoints(edge,2);
        finish = endpoints(edge,1);
    end
    winner = names{1}(start);
    loser = names{1}(finish);
    
    competitor_string{1}(j) = strcat(winner, ' > ', {' '}, loser);
end

set(gca,'XTick',(1:min(10,E)),'XTickLabel',competitor_string{1})
set(gca,'FontSize',12)
xtickangle(15)

ylabel('Flow ','FontSize',18,'interpreter','latex')
xlabel('Competitor Pairs ','FontSize',18,'interpreter','latex')
title('Ten Strongest Transitive Flows ','FontSize',18,'interpreter','latex')


groupwidth = min(0.8, 3/(3 + 1.5));
for i = 1:3
    % Calculate center of each bar
    x = (1:min(10,E)) - groupwidth/2 + (2*i-1) * groupwidth / (2*3);
    hold on
    errorbar(x, Bar_Data(:,i), Bar_Error(:,i),'k','LineWidth',1.5, 'linestyle', 'none');
end
l = legend('$f$','$f_{trans}$','$f_{cyc}$');
set(l,'Location','Best','FontSize',16,'Orientation','horizontal','interpreter','latex')

% sorted by cyclic
[~,flow_ranks] = sort(abs(f.rot.exp),'descend');
Bar_Data = [abs(f.exp(flow_ranks(1:min(10,E)))),...
    sign(f.exp(flow_ranks(1:min(10,E)))).*f.con.exp(flow_ranks(1:min(10,E))),...
    sign(f.exp(flow_ranks(1:min(10,E)))).*f.rot.exp(flow_ranks(1:min(10,E)))];
Bar_Error = sqrt([var(flow_ranks(1:min(10,E))),...
    var_trans(flow_ranks(1:min(10,E))),...
    var_cyc(flow_ranks(1:min(10,E)))]);


ten_largest_cyclic_flow = figure('Name','Large Cyclic Edge Flows','NumberTitle','off');
clf
flow_bar_plot = bar(Bar_Data,'BarWidth',1);
grid on
axis tight

competitor_string = cell([1,1]);
for j = 1:min(10,E)
    edge = flow_ranks(j);
    if f.exp(edge) > 0
        start = endpoints(edge,1);
        finish = endpoints(edge,2);
    else
        start = endpoints(edge,2);
        finish = endpoints(edge,1);
    end
    winner = names{1}(start);
    loser = names{1}(finish);
    
    competitor_string{1}(j) = strcat(winner, ' > ', {' '}, loser);
end

set(gca,'XTick',(1:min(10,E)),'XTickLabel',competitor_string{1})
set(gca,'FontSize',12)
xtickangle(15)

ylabel('Flow ','FontSize',18,'interpreter','latex')
xlabel('Competitor Pairs ','FontSize',18,'interpreter','latex')
title('Ten Strongest Cyclic Flows ','FontSize',18,'interpreter','latex')


groupwidth = min(0.8, 3/(3 + 1.5));
for i = 1:3
    % Calculate center of each bar
    x = (1:min(10,E)) - groupwidth/2 + (2*i-1) * groupwidth / (2*3);
    hold on
    errorbar(x, Bar_Data(:,i), Bar_Error(:,i),'k','LineWidth',1.5, 'linestyle', 'none');
end
l = legend('$f$','$f_{trans}$','$f_{cyc}$');
set(l,'Location','Best','FontSize',16,'Orientation','horizontal','interpreter','latex')


%% Sampling plots
if input.input.settings.sampling.on_off == 1
    %% display marginal posterior distributions for measures
    % get data
    transitivity = input.measures.transitivity;
    intransitivity = input.measures.intransitivity;
    
    transitivity_dist = transitivity.sampled.post.dist;
    edges = transitivity.sampled.post.edges;
    trans_bin_centers = (edges(1:end-1) + edges(2:end))/2;
    
    transitivity_dist_prior = transitivity.sampled.prior.dist;
    edges = transitivity.sampled.prior.edges;
    trans_bin_centers_prior = (edges(1:end-1) + edges(2:end))/2;
    
    
    intransitivity_dist = intransitivity.sampled.post.dist;
    edges = intransitivity.sampled.post.edges;
    intrans_bin_centers = (edges(1:end-1) + edges(2:end))/2;
    
    intransitivity_dist_prior = intransitivity.sampled.prior.dist;
    edges = intransitivity.sampled.prior.edges;
    intrans_bin_centers_prior = (edges(1:end-1) + edges(2:end))/2;
    
    
    % plot
    marginal_dist_for_measures = figure('Name','Marginal Posterior Distributions for Measures','NumberTitle','off');
    clf
    
    subplot(2,1,1)
    grid on
    hold on
    bar(trans_bin_centers_prior,transitivity_dist_prior,1,'r')
    bar(trans_bin_centers,transitivity_dist,1,'b')
    xlim([0,max(max(trans_bin_centers_prior),max(trans_bin_centers))])
    xlabel('Transitivity ','FontSize',18,'interpreter','latex')
    ylabel('Probability ','FontSize',18,'interpreter','latex')
    l = legend('Prior','Posterior');
    set(l,'FontSize',14,'interpreter','latex','location','northwest')
    
    subplot(2,1,2)
    grid on
    hold on
    bar(intrans_bin_centers_prior,intransitivity_dist_prior,1,'r')
    bar(intrans_bin_centers,intransitivity_dist,1,'b')
    xlim([0,max(max(intrans_bin_centers_prior),max(intrans_bin_centers))])
    xlabel('Intransitivity ','FontSize',18,'interpreter','latex')
    ylabel('Probability ','FontSize',18,'interpreter','latex')
    l = legend('Prior','Posterior');
    set(l,'FontSize',14,'interpreter','latex','location','northeast')
    
    
    
    %% display posterior distribution for ratings
    
    % get data
    ratings = input.rating;
    ranks = input.ranking;
    ratings_dist = ratings.sampled.post.dist;
    edges = ratings.sampled.post.edges(1,:)';
    ratings_bins = (edges(1:end-1) + edges(2:end))/2;
    names = input.input.names;
    
    % plot
    ratings_distribution = figure('Name','Ratings Distribution','NumberTitle','off');
    clf
    colormap summer
    imagesc(fliplr(ratings_dist(ranks.exp,:)'))
    colorbar
    set(gca,'xtick',(1:V),'xticklabel',names{1}(ranks.exp))
    set(gca,'ytick',(1:3:length(ratings_bins)-1),'yticklabel',flipud((ratings_bins(1:3:end-1) + ratings_bins(2:3:end))/2))
    grid on
    ylabel('Ratings','FontSize',18,'interpreter','latex')
    title('Posterior Distribution for Ratings ','FontSize',18,'interpreter','latex')
    xlabel('Competitors','FontSize',18,'interpreter','latex')
    xtickangle(20)
    axis square
    
    
    
    %% display posterior distribution for rankings
    
    % get data
    rank_dist = input.ranking.sampled.post.dist;
    ranks = input.ranking;
    names = input.input.names;
    V = input.dimensions.V;
    
    % plot
    rankings_distribution = figure('Name','Rankings Distribution','NumberTitle','off');
    clf
    colormap summer
    imagesc((rank_dist(:,ranks.mle)))
    colorbar
    set(gca,'xtick',(1:V),'xticklabel',names{1}(ranks.mle))
    set(gca,'ytick',(1:2:V))
    grid on
    ylabel('Rank ','FontSize',18,'interpreter','latex')
    title('Posterior Rank Distribution','FontSize',18,'interpreter','latex')
    xlabel('Individuals','FontSize',18,'interpreter','latex')
    xtickangle(20)
    axis square
end



%% Hypothesis Testing Plots
if input.input.settings.hypothesis_testing.on_off == 1
    %% display ratings using mle perfectly transitive
    % get data
    ratings = input.rating;
    ranks = input.ranking;
    perfectly_trans = input.hypothesis_testing.perfectly_transitive;
    names = input.input.names;
    
    % plot
    map_perfectly_transitive = figure('Name','MAP Ratings Perfectly Transitive','NumberTitle','off');
    clf
    bar([ratings.exp(ranks.mle),ratings.mle(ranks.mle),perfectly_trans.optimal_ratings(ranks.mle)],'BarWidth',1)
    grid on
    set(gca,'FontSize',14)
    set(gca,'XTick',(1:V),'XTickLabel',names{1}(ranks.mle))
    l = legend('Expected ','MAP ','MAP Perfectly Transitive');
    set(l,'FontSize',18,'Location','northeast')
    xlabel('Competitors ','FontSize',18,'interpreter','latex')
    ylabel('Ratings ','FontSize',18,'interpreter','latex')
    title('Ratings for Maximum a Posteriori Perfectly Transitive Model ','FontSize',18,'interpreter','latex')
    
    %% display comparison to data for perfectly transitive
    
    % get data
    win_frequencies = input.data.win_frequencies;
    p = input.hypothesis_testing.perfectly_transitive.optimal_p;
    endpoints = input.topology.edge_to_endpoints;
    names = input.input.names;
    events = input.data.events; 
    confidence_int = input.hypothesis_testing.perfectly_transitive.confidence_int;
    E = input.dimensions.E;
    [~,worst_edges] = sort(input.hypothesis_testing.perfectly_transitive.match_to_data_per_edge.p_test_two_sided,'ascend'); 

    
    % plot
    
    perfectly_transitive_match_to_data = figure('Name','MAP Perfectly Transitive Match to Data','NumberTitle','off');
    clf
    bar([p,win_frequencies],'BarWidth',1,'Facealpha',0.5)
    hold on
    
    grid on
    
    competitor_string = cell([1,1]);
    for j = 1:E
        if p(j) > 0.5
            start = endpoints(j,1);
            finish = endpoints(j,2);
        else
            start = endpoints(j,2);
            finish = endpoints(j,1);
        end
        winner = names{1}(start);
        loser = names{1}(finish);
        
        competitor_string{1}(j) = strcat(winner, ' > ', {' '}, loser);
    end
    
    set(gca,'XTick',(1:E),'XTickLabel',competitor_string{1})
    set(gca,'FontSize',8)
    xtickangle(90)
    
    ylabel('Win Probability ','FontSize',18,'interpreter','latex')
    xlabel('Pairs ','FontSize',18,'interpreter','latex')
    title('Observed Win Frequencies and MAP Perfectly Transitive Win Probabilities ','FontSize',18,'interpreter','latex')
    
    groupwidth = min(0.8, 2/(2 + 1.5));
    x = (1:E) - groupwidth/2 + (2-1) * groupwidth / (2*2);
    hold on
    errorbar(x, p, p - confidence_int.fifty(:,1),...
        confidence_int.fifty(:,2) - p,'k','LineWidth',1.5, 'linestyle', 'none');
    errorbar(x, p, p - confidence_int.ninety_five(:,1),...
        confidence_int.ninety_five(:,2) - p,'k','LineWidth',1, 'linestyle', 'none');
    
    xlim([0,min(E+1,60)]);
    ylim([0,1]);
    
    l = legend('MAP Perf. Trans. ','Observed ','50 percent Confidence','95 percent Confidence ');
    set(l,'FontSize',14,'Location','Best','interpreter','latex')
    
    
    % zoom in on ten worst edges
    
    perfectly_transitive_worst_match_to_data = figure('Name','MAP Perfectly Transitive Worst Match to Data','NumberTitle','off');
    clf
    bar([p(worst_edges(1:min(10,E))),win_frequencies(worst_edges(1:min(10,E)))],'BarWidth',1,'Facealpha',0.5)
    hold on
    
    grid on
    
    competitor_string = cell([1,1]);
    for j = 1:min(10,E)
        edge = worst_edges(j);
        if p(j) > 0.5
            start = endpoints(edge,1);
            finish = endpoints(edge,2);
        else
            start = endpoints(edge,2);
            finish = endpoints(edge,1);
        end
        winner = names{1}(start);
        loser = names{1}(finish);
        
        competitor_string{1}(j) = strcat(winner, ' > ', {' '}, loser);
    end
    
    set(gca,'XTick',(1:min(10,E)),'XTickLabel',competitor_string{1})
    set(gca,'FontSize',8)
    xtickangle(90)
    
    ylabel('Win Probability ','FontSize',18,'interpreter','latex')
    xlabel('Pairs ','FontSize',18,'interpreter','latex')
    title('MAP Perfectly Transitive Win Probabilities Worst Match to Data ','FontSize',18,'interpreter','latex')
    
    groupwidth = min(0.8, 2/(2 + 1.5));
    x = (1:min(10,E)) - groupwidth/2 + (2-1) * groupwidth / (2*2);
    hold on
    errorbar(x, p(worst_edges(1:min(10,E))), p(worst_edges(1:min(10,E))) - confidence_int.fifty((worst_edges(1:min(10,E))),1),...
        confidence_int.fifty((worst_edges(1:min(10,E))),2) - p(worst_edges(1:min(10,E))),...
        'k','LineWidth',1.5, 'linestyle', 'none');
    errorbar(x, p(worst_edges(1:min(10,E))), p(worst_edges(1:min(10,E))) - confidence_int.ninety_five((worst_edges(1:min(10,E))),1),...
        confidence_int.ninety_five((worst_edges(1:min(10,E))),2) - p(worst_edges(1:min(10,E))),...
        'k','LineWidth',1, 'linestyle', 'none');
    
    xlim([0.5,10.5]);
    ylim([0,1]);
    
    l = legend('MAP Perf. Trans. ','Observed ','50 percent Confidence','95 percent Confidence ');
    set(l,'FontSize',14,'Location','Best','interpreter','latex')
    
    
    %% display comparison to data for mle perfectly cyclic
    
    % get data
    win_frequencies = input.data.win_frequencies;
    p = input.hypothesis_testing.perfectly_cyclic.optimal_p;
    endpoints = input.topology.edge_to_endpoints;
    names = input.input.names;
    events = input.data.events; 
    confidence_int = input.hypothesis_testing.perfectly_cyclic.confidence_int;
    E = input.dimensions.E;
    [~,worst_edges] = sort(input.hypothesis_testing.perfectly_cyclic.match_to_data_per_edge.p_test_two_sided,'ascend'); 

    
    % plot
    
    perfectly_cyclic_match_to_data = figure('Name','MAP Perfectly Cyclic Match to Data','NumberTitle','off');
    clf
    bar([p,win_frequencies],'BarWidth',1,'Facealpha',0.5)
    hold on
    
    grid on
    
    competitor_string = cell([1,1]);
    for j = 1:E
        if p(j) > 0.5
            start = endpoints(j,1);
            finish = endpoints(j,2);
        else
            start = endpoints(j,2);
            finish = endpoints(j,1);
        end
        winner = names{1}(start);
        loser = names{1}(finish);
        
        competitor_string{1}(j) = strcat(winner, ' > ', {' '}, loser);
    end
    
    set(gca,'XTick',(1:E),'XTickLabel',competitor_string{1})
    set(gca,'FontSize',8)
    xtickangle(90)
    
    ylabel('Win Probability ','FontSize',18,'interpreter','latex')
    xlabel('Pairs ','FontSize',18,'interpreter','latex')
    title('Observed Win Frequencies and MAP Perfectly Cyclic Win Probabilities ','FontSize',18,'interpreter','latex')
    
    groupwidth = min(0.8, 2/(2 + 1.5));
    x = (1:E) - groupwidth/2 + (2-1) * groupwidth / (2*2);
    hold on
    errorbar(x, p, p - confidence_int.fifty(:,1),...
        confidence_int.fifty(:,2) - p,'k','LineWidth',1.5, 'linestyle', 'none');
    errorbar(x, p, p - confidence_int.ninety_five(:,1),...
        confidence_int.ninety_five(:,2) - p,'k','LineWidth',1, 'linestyle', 'none');
    
    xlim([0,min(E+1,60)]);
    ylim([0,1]);
    
    l = legend('MAP Perf. Cyclic ','Observed ','50 percent Confidence','95 percent Confidence ');
    set(l,'FontSize',14,'Location','Best','interpreter','latex')
    
    
    % zoom in on ten worst edges
    
    perfectly_cyclic_worst_match_to_data = figure('Name','MAP Perfectly Cyclic Worst Match to Data','NumberTitle','off');
    clf
    bar([p(worst_edges(1:min(10,E))),win_frequencies(worst_edges(1:min(10,E)))],'BarWidth',1,'Facealpha',0.5)
    hold on
    
    grid on
    
    competitor_string = cell([1,1]);
    for j = 1:min(10,E)
        edge = worst_edges(j);
        if p(j) > 0.5
            start = endpoints(edge,1);
            finish = endpoints(edge,2);
        else
            start = endpoints(edge,2);
            finish = endpoints(edge,1);
        end
        winner = names{1}(start);
        loser = names{1}(finish);
        
        competitor_string{1}(j) = strcat(winner, ' > ', {' '}, loser);
    end
    
    set(gca,'XTick',(1:min(10,E)),'XTickLabel',competitor_string{1})
    set(gca,'FontSize',8)
    xtickangle(90)
    
    ylabel('Win Probability ','FontSize',18,'interpreter','latex')
    xlabel('Pairs ','FontSize',18,'interpreter','latex')
    title('MAP Perfectly Cyclic Win Probabilities Worst Match to Data ','FontSize',18,'interpreter','latex')
    
    groupwidth = min(0.8, 2/(2 + 1.5));
    x = (1:min(10,E)) - groupwidth/2 + (2-1) * groupwidth / (2*2);
    hold on
    errorbar(x, p(worst_edges(1:min(10,E))), p(worst_edges(1:min(10,E))) - confidence_int.fifty((worst_edges(1:min(10,E))),1),...
        confidence_int.fifty((worst_edges(1:min(10,E))),2) - p(worst_edges(1:min(10,E))),...
        'k','LineWidth',1.5, 'linestyle', 'none');
    errorbar(x, p(worst_edges(1:min(10,E))), p(worst_edges(1:min(10,E))) - confidence_int.ninety_five((worst_edges(1:min(10,E))),1),...
        confidence_int.ninety_five((worst_edges(1:min(10,E))),2) - p(worst_edges(1:min(10,E))),...
        'k','LineWidth',1, 'linestyle', 'none');
    
    xlim([0.5,10.5]);
    ylim([0,1]);
    
    l = legend('MAP Perf. Cyclic ','Observed ','50 percent Confidence','95 percent Confidence ');
    set(l,'FontSize',14,'Location','Best','interpreter','latex')
    
    %% display comparison to data for mle
    % get data
    win_frequencies = input.data.win_frequencies;
    p = input.hypothesis_testing.mle.optimal_p;
    endpoints = input.topology.edge_to_endpoints;
    names = input.input.names;
    events = input.data.events; 
    confidence_int = input.hypothesis_testing.mle.confidence_int;
    E = input.dimensions.E;
    [~,worst_edges] = sort(input.hypothesis_testing.mle.match_to_data_per_edge.p_test_two_sided,'ascend'); 

    
    % plot
    
    MAP_match_to_data = figure('Name','MAP Match to Data','NumberTitle','off');
    clf
    bar([p,win_frequencies],'BarWidth',1,'Facealpha',0.5)
    hold on
    
    grid on
    
    competitor_string = cell([1,1]);
    for j = 1:E
        if p(j) > 0.5
            start = endpoints(j,1);
            finish = endpoints(j,2);
        else
            start = endpoints(j,2);
            finish = endpoints(j,1);
        end
        winner = names{1}(start);
        loser = names{1}(finish);
        
        competitor_string{1}(j) = strcat(winner, ' > ', {' '}, loser);
    end
    
    set(gca,'XTick',(1:E),'XTickLabel',competitor_string{1})
    set(gca,'FontSize',8)
    xtickangle(90)
    
    ylabel('Win Probability ','FontSize',18,'interpreter','latex')
    xlabel('Pairs ','FontSize',18,'interpreter','latex')
    title('Observed Win Frequencies and MAP Win Probabilities ','FontSize',18,'interpreter','latex')
    
    groupwidth = min(0.8, 2/(2 + 1.5));
    x = (1:E) - groupwidth/2 + (2-1) * groupwidth / (2*2);
    hold on
    errorbar(x, p, p - confidence_int.fifty(:,1),...
        confidence_int.fifty(:,2) - p,'k','LineWidth',1.5, 'linestyle', 'none');
    errorbar(x, p, p - confidence_int.ninety_five(:,1),...
        confidence_int.ninety_five(:,2) - p,'k','LineWidth',1, 'linestyle', 'none');
    
    xlim([0,min(E+1,60)]);
    ylim([0,1]);
    
    l = legend('MAP ','Observed ','50 percent Confidence','95 percent Confidence ');
    set(l,'FontSize',14,'Location','Best','interpreter','latex')
    
    
    % zoom in on ten worst edges
    
    map_worst_match_to_data = figure('Name','MAP Worst Match to Data','NumberTitle','off');
    clf
    bar([p(worst_edges(1:min(10,E))),win_frequencies(worst_edges(1:min(10,E)))],'BarWidth',1,'Facealpha',0.5)
    hold on
    
    grid on
    
    competitor_string = cell([1,1]);
    for j = 1:min(10,E)
        edge = worst_edges(j);
        if p(j) > 0.5
            start = endpoints(edge,1);
            finish = endpoints(edge,2);
        else
            start = endpoints(edge,2);
            finish = endpoints(edge,1);
        end
        winner = names{1}(start);
        loser = names{1}(finish);
        
        competitor_string{1}(j) = strcat(winner, ' > ', {' '}, loser);
    end
    
    set(gca,'XTick',(1:min(10,E)),'XTickLabel',competitor_string{1})
    set(gca,'FontSize',8)
    xtickangle(90)
    
    ylabel('Win Probability ','FontSize',18,'interpreter','latex')
    xlabel('Pairs ','FontSize',18,'interpreter','latex')
    title('MAP Win Probabilities Worst Match to Data ','FontSize',18,'interpreter','latex')
    
    groupwidth = min(0.8, 2/(2 + 1.5));
    x = (1:min(10,E)) - groupwidth/2 + (2-1) * groupwidth / (2*2);
    hold on
    errorbar(x, p(worst_edges(1:min(10,E))), p(worst_edges(1:min(10,E))) - confidence_int.fifty((worst_edges(1:min(10,E))),1),...
        confidence_int.fifty((worst_edges(1:min(10,E))),2) - p(worst_edges(1:min(10,E))),...
        'k','LineWidth',1.5, 'linestyle', 'none');
    errorbar(x, p(worst_edges(1:min(10,E))), p(worst_edges(1:min(10,E))) - confidence_int.ninety_five((worst_edges(1:min(10,E))),1),...
        confidence_int.ninety_five((worst_edges(1:min(10,E))),2) - p(worst_edges(1:min(10,E))),...
        'k','LineWidth',1, 'linestyle', 'none');
    
    xlim([0.5,10.5]);
    ylim([0,1]);
    
    l = legend('MAP ','Observed ','50 percent Confidence','95 percent Confidence ');
    set(l,'FontSize',14,'Location','Best','interpreter','latex')
    
    %% display scatter plots comparing mle models to data
    % get data
    p_empirical = input.data.win_frequencies;
    p_map = input.hypothesis_testing.mle.optimal_p;
    p_trans = input.hypothesis_testing.perfectly_transitive.optimal_p;
    p_cyc = input.hypothesis_testing.perfectly_cyclic.optimal_p;
    
    % plot
    match_to_data_scatter = figure('Name','Match to Data Scatter','NumberTitle','off');
    clf
    hold on
    grid on
    plot([0,1],[0,1],'k-','LineWidth',1)
    scatter(p_empirical,p_cyc,30,[1,0,0],'fill')
    scatter(p_empirical,p_trans,30,[0,1,0],'fill')
    scatter(p_empirical,p_map,30,[0,0,1],'fill')
    
    axis square
    
    xlabel('Observed Win Frequencies','FontSize',18,'interpreter','latex')
    ylabel('Win Frequencies from MAP Models','FontSize',18,'interpreter','latex')
    title('Match to Data','FontSize',18,'interpreter','latex')
    l = legend('Perfect Match','Perfectly Cyclic','Perfectly Transitive','MAP');
    set(l,'FontSize',14,'location','northwest','interpreter','latex')
    
    
end

%% Plausible regions
if input.input.settings.plausible_regions.on_off == 1
    
    % get data
    plausible_bounds = input.measures.plausible_bounds;
    transitivity = input.measures.transitivity;
    intransitivity = input.measures.intransitivity;
    
    
    % plot
    plausible_region_plot = figure('Name','Plausible Region','NumberTitle','off');
    clf
    hold on
    grid on
    axis equal
    
    % display plausible absolute transitivity
    fill([plausible_bounds.trans.lower,plausible_bounds.trans.lower,...
        plausible_bounds.trans.upper,plausible_bounds.trans.upper],...
        [0,1.2*plausible_bounds.intrans.upper,1.2*plausible_bounds.intrans.upper,0],'b','Facealpha',0.2,'EdgeColor','none')
    plot([plausible_bounds.trans.lower,plausible_bounds.trans.lower],...
        [0,1.2*plausible_bounds.intrans.upper],'b','LineWidth',2)
    plot([plausible_bounds.trans.upper,plausible_bounds.trans.upper],...
        [0,1.2*plausible_bounds.intrans.upper],'b','LineWidth',2)
    
    
    % display plausible absolute intransitivity
    fill([0,1.2*plausible_bounds.trans.upper,1.2*plausible_bounds.trans.upper,0],...
        [plausible_bounds.intrans.lower,plausible_bounds.intrans.lower,...
        plausible_bounds.intrans.upper,plausible_bounds.intrans.upper],...
        'r','Facealpha',0.2,'EdgeColor','none')
    plot([0,1.2*plausible_bounds.trans.upper],[plausible_bounds.intrans.lower,plausible_bounds.intrans.lower],...
        'r','LineWidth',2)
    plot([0,1.2*plausible_bounds.trans.upper],[plausible_bounds.intrans.upper,plausible_bounds.intrans.upper],...
        'r','LineWidth',2)
   
    % plot point estimators
    scatter(transitivity.mle,intransitivity.mle,30,'r','x','Linewidth',1.5)
    scatter(transitivity.exp,intransitivity.exp,30,'b','o','Linewidth',1.5)
    
    set(gca,'FontSize',16)
    xlabel('$||f_{trans}||_2$ ','FontSize',16,'interpreter','latex')
    ylabel('$||f_{cyc}||_2$','FontSize',16,'interpreter','latex')
    title('Plausible Region','FontSize',18)
    
    l = legend('Plausible Trans','Smallest ','Greatest','Plausible Intrans.','Smallest','Greatest','MAP Flow','Expected Flow');
    set(l,'FontSize',10,'interpreter','latex','location','west')
    
    axis([0,1.2*plausible_bounds.trans.upper,0,1.2*plausible_bounds.intrans.upper])
    
end


%% comparison scatter plot on transitivity/intransitivity plane
fid = fopen('../Results/Measures_Summary.txt');
measures_for_comparison = textscan(fid,'%s','Delimiter','\n');
fclose(fid);

measures_for_comparison = measures_for_comparison{1};
categories = {};
example_transitivity = {};
example_intransitivity = {};

transitivity_intransitivity_comparison_plot = figure('Name','Trans. Intras. Plane','NumberTitle','off');
clf
hold on
grid on
axis equal
M = 0;
for j = 1:length(measures_for_comparison)
    example = regexp(measures_for_comparison{j}, '\s+','split');
    
    category_index = 0;
    example_category = example{1};
    for k = 1:length(categories)
        if strcmp(example_category,categories{k}) == 1
            category_index = k;
            
            example_transitivity{category_index} = [example_transitivity{category_index},str2num(example{3})];
            example_intransitivity{category_index} = [example_intransitivity{category_index},str2num(example{4})];
        
            M = max(M,max(str2num(example{3}),str2num(example{4})));
        end
    end
    
    if category_index == 0
        categories{end+1} = example_category;
        category_index = length(categories);
        
        example_transitivity{category_index} = [str2num(example{3})];
        example_intransitivity{category_index} = [str2num(example{4})];
        M = max(M,max(str2num(example{3}),str2num(example{4})));
    end
    
end

plot([0,1.2*M],[0,1.2*M],'-.','Color',[0.1,0.1,0.1],'Linewidth',0.5)
plot([0,2*1.2*M],[0,1.2*M],'-.','Color',[0.1,0.1,0.1],'Linewidth',0.5)
plot([0,1.2*M],[0,2*1.2*M],'-.','Color',[0.1,0.1,0.1],'Linewidth',0.5)

for k = 1:length(categories)
    categories{k} = strrep(categories{k},'_',' ');
    scatter_plot{k} = scatter(example_transitivity{k},example_intransitivity{k},30,'fill');
end

scatter_plot{k+1} = scatter(input.measures.transitivity.mle/sqrt(E),input.measures.intransitivity.mle/sqrt(E),30,'fill');
categories{end+1} = strrep(input.input.filename,'_',' ');
categories{end} = strrep(categories{end},'.mat',' ');

set(gca,'FontSize',16)
xlabel('$||f_{trans}||_2$ ','FontSize',16,'interpreter','latex')
ylabel('$||f_{cyc}||_2$','FontSize',16,'interpreter','latex')
title('Comparison on Transitivity/Intransitivity Plane','FontSize',18)

xlim([0,1.2*M])
ylim([0,1.2*M])

legend_labels = {};
legend_labels = {'75 percent Cyclic','50 percent Cyclic','25 percent Cyclic'};
for k = 1:length(categories)
    legend_labels{end + 1} = categories{k};
end
l = legend(legend_labels );
set(l,'FontSize',12,'Location','northeastoutside','interpreter','latex')

drawnow



end