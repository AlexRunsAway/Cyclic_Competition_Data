%% analyze win loss data for cyclic and transitive components
function [output] = Estimation_Engine(input)
%% Inputs:
% 1. input: should be a struct containing
%       a. input.names: a txt list containing the names of each competitor
%       b. input.data.winloss: a matrix containing win-loss data, 
%       c. input.data.ties: a matrix containing ties data
%       d. input.settings: a struct containing all the settings generated
%       by the driver
%             (i). .display: 
%                           .print_results: 0 off, 1 for on
%             (ii). .assumptions: prior assumptions for estimator
%                           .ties: 0 for not including ties, 1 for
%                           including ties
%                           .tie_weighting: an integer from 0 to 1, amount
%                           ties are weighted in prior
%                           .prior_mode: from 1 to 7
%                                          1 adds 2 ties
%                                          2 adds 1 tie
%                                          3 adds no ties
%                                          4 input value by hand
%                                          5 estimate from moments of
%                                          win-frequencies
%                                          6 mle estimate from
%                                          win-frequencies
%                                  for mode 4 need to input value, for 5-6
%                                  give option to provide additional win
%                                  frequency data
%                           .beta: a positive number (if use custom beta)
%                           .win_frequencies: empirical distribution of win
%                           frequencies if want to use alternative data,
%                           stored as a list of win frequencies
%                           .events_threshold: minimum number of events
%                           needed to include in the estimator
%            (iii). .asymptotic_corrector: whether to turn on asymptotic
%            correction or not... return error if not enough data to use
%            (iv). .sampling: what sampling techniques to estimate
%            uncertainty in estimators
%                           .on_off: 0 off, 1 for on
%                           .n_realization: number of realizations to use
%                           .confidence: bounds on confidence interval
%                           .compare_to_prior: 0 for no, 1 for yes (use
%                           kolmogorov distance on marginals)
%            (v) .hypothesis_testing: how/what hypothesis to test
%                           .on_off: 0 off, 1 for on
%            (vi) .plausible_regions: get plausible regions corresponding
%            to different bounds on the transitivity/intransitivity
%            measures. How to define "plausible":
%                           .on_off: 0 off, 1 on
%                           .bounds_to_find
%                                .min_trans: 0 off, 1 on
%                                .max_trans:
%                                .min_intrans:
%                                .max_trans:
%                           .plausibility: value which defines threshold
%                           for "plausible"
%                           .best_model: 1 for testing whether mle is
%                           plausible, 2 for testing whether most plausible
%                           model is plausible
%       e. input.filename: a string containing the file to save output to


%% Outputs
% 2. output: a struct containing all the outputs, will depend on inputs
%       a. .input: contains the full input struct used to generate the
%       output
%       b. .topology: contains network structure extracted from event
%       record
%       c. .operators: contains gradient (and curl if complete)
%       e. .dimensions: contains number of competitors (V), edges (E), and
%       loops (L)
%       f. .prior: contains parameters used for prior on win probabilities
%       g. .data: contains data reformatted to match edge indexing
%       h. .f: contains the logit edge flow, its point estimates, and its
%       components (con for conservative = transitive, rot for rotational =
%       cyclic)
%       i. .measures: contains the sizes of the components
%       j. .ratings: contains the ratings
%       k. .ranking: contains the ranking
%       l. .vorticity: contains the vorticities
%       m. .hypothesis_testing: contains the results from hypothesis
%       testing


%% Read input struct, convert to local variables
fprintf('\n\n <strong> Estimation Engine: </strong>')
fprintf('\n Loading Data and Settings: ')

% data (loaded by driver and formatted)
names = input.names; % names of the competitors
win_loss_data = input.data.win_loss; % win loss matrix
ties_data = input.data.ties; % ties matrix
outside_win_freq_data = input.data.win_freq;

% settings
display_settings = input.settings.display; % a struct whose entries signal what to display
prior_assumptions = input.settings.assumptions; % a struct containing prior assumptions
asymptotic_corrector_on_off = input.settings.asymptotic_corrector;
sampling_settings = input.settings.sampling; % a struct with sampling settings
hypothesis_testing = input.settings.hypothesis_testing;
plausible_region_settings = input.settings.plausible_regions; % a struct with plausible region settings

output_filename = input.filename; %filename to save output to


%% Get win matrix, loss matrix, event matrix, and ties matrix
Wins = win_loss_data; % i j entry is number of times type i beat type j
Losses = win_loss_data';
Ties = ties_data;
Events = Wins + Losses;


fprintf(' Finished ')

%% Prune network
fprintf('\n Pruning Network: ')

Wins(Events < input.settings.assumptions.events_threshold) = 0;
Losses(Events < input.settings.assumptions.events_threshold) = 0;
Ties(Events < input.settings.assumptions.events_threshold) = 0;
Events(Events < input.settings.assumptions.events_threshold) = 0;

fprintf(' Finished ')

%% Get dimensions and topology
fprintf('\n Extracting Network Topology: ')

if prod(prod(isnan(Ties))) || prior_assumptions.ties == 0
    [dimensions,A,adjacency_list,complete_flag,edge_to_endpoints,...
        edge_indices] = Get_Topology(Events);
else
    [dimensions,A,adjacency_list,complete_flag,edge_to_endpoints,...
    edge_indices] = Get_Topology(Events+Ties);
end

V = dimensions.V; % number of competitors
E = dimensions.E; % number of edges
L = dimensions.L; % number of loops

fprintf(' Finished ')

%% compute empirical win frequencies and flow
fprintf('\n Estimating Edge Flow: ')

events = reshape(Events,[V^2,1]);
wins = reshape(Wins,[V^2,1]);
events(isnan(events)) = [];
wins(isnan(wins)) = [];




%% Set up Bayesian Estimator for forces (use Beta distribution since it is conjugate prior)
%% WARNING MAKE SURE IF TREAT TIES AS HALF WIN HALF LOSS THAT THIS IS CONSISTENT WITH ESTIMATION OF BETA
prior_mode = prior_assumptions.prior_mode; %(uniform = Bayes, Jefferys, Haldane, Custom, Empirical via Moments, Empirical via Maximum Likelihood)
% most reasonable is likely 1, 5
if prior_mode == 1 % uniform = Bayes
    beta = 1;
elseif prior_mode == 2 % Jeffereys
    beta = 1/2;
elseif prior_mode == 3 % Haldane
    beta = 0;
elseif prior_mode == 4 % custom
    beta = prior_assumptions.beta;
elseif prior_mode == 5
    if prior_assumptions.use_outside_win_freq == 0
        wins_data_for_beta = [wins;events-wins];
        events_data_for_beta = [events;events];
    else
        wins_data_for_beta = [outside_win_freq_data.wins;outside_win_freq_data.events-outside_win_freq_data.wins];
        events_data_for_beta = [outside_win_freq_data.events;outside_win_freq_data.events];
    end
    beta = Estimate_Beta(wins_data_for_beta,events_data_for_beta);
end

% elseif prior_mode == 5 % Empirical via Moments
%     if prior_assumptions.use_outside_win_freq == 0
%         var_win_frequency = var([win_frequencies;1-win_frequencies]);
%     else
%         var_win_frequency = var([outside_win_freq_data;1-outside_win_freq_data]);
%     end
%     beta = (1/2)*(1/(4*var_win_frequency)-1); % b/c mean win frequency = 1/2
% elseif prior_mode == 6 % Empirical via Maximum Likelihood
%     if prior_assumptions.use_outside_win_freq == 0
%         parameters = mle([win_frequencies;1-win_frequencies],'distribution','Beta');
%     else
%         parameters = mle([outside_win_freq_data;1-outside_win_freq_data],'distribution','Beta');
%     end
%     parameters = mle(win_frequencies,'distribution','Beta');
%     beta = parameters(2);
% end

%% adjust for ties
gamma = beta;
if prior_assumptions.ties == 1
    gamma = beta*ones([E,1]);
    for k = 1:E
        i = edge_to_endpoints(k,1);
        j = edge_to_endpoints(k,2);
        gamma(k) = beta + prior_assumptions.tie_weighting*Ties(i,j)/2;
    end
end

%% make list of wins, events, losses, ties by edge rather than endpoints
wins = nan([E,1]);
losses = nan([E,1]);
events = nan([E,1]);
ties = nan([E,1]);
for k = 1:E
    i = edge_to_endpoints(k,1);
    j = edge_to_endpoints(k,2);
    wins(k) = Wins(i,j);
    losses(k) = Losses(i,j);
    events(k) = Events(i,j);
    if prod(prod(isnan(Ties))) == 0 && prior_assumptions.ties == 1
        ties(k) = Ties(i,j);
    end
end


%% Compute range of forces that can be returned by the estimator
f_max = (1/2)*max(abs(log((wins + gamma)./(losses + gamma))));
f_range = max(1,5*f_max)*[-1,1]; % sets range of f we might observe from the data

%% Generate pdf for forces, compute maximum likelihood estimator for forces, expected forces
[f,posterior_f] = Get_f_Posterior_and_Estimates(Wins,Losses,gamma,E,edge_to_endpoints);

fprintf(' Finished')

%% Get Operators (note: only generates C if complete, uses overdetermined triangle basis)
fprintf('\n Building Operators: ')
[G,C,cycles] = Get_Operators(E,V,edge_to_endpoints,edge_indices,complete_flag);

fprintf(' Finished')

%% Check if network is connected
connected_components = sum(svds(G'*G,6,'smallest') == 0);

if connected_components > 1
    fprintf('\n Error: Network is not connected. Has at least %d components. \n',connected_components);
else
    
    %% Perform HHD
    fprintf('\n Performing HHD: ')
    % mle flow
    [flow,phi,theta,measures] = Perform_HHD(f.mle,G,complete_flag,C);
    
    f.con.mle = flow.con;
    f.rot.mle = flow.rot;
    ratings.mle = phi;
    if complete_flag == 1
        vorticities.mle = theta;
    end
    
    intensity.mle = measures.total;
    transitivity.mle = measures.trans;
    transitivity.rel.mle = measures.trans/measures.total;
    intransitivity.mle = measures.intrans;
    intransitivity.rel.mle = measures.intrans/measures.total;
    rho.mle = measures.rho;
    
    
    % expected flow
    [flow,phi,theta,measures] = Perform_HHD(f.exp,G,complete_flag,C);
    
    f.con.exp = flow.con;
    f.rot.exp = flow.rot;
    ratings.exp = phi;
    if complete_flag == 1
        vorticities.exp = theta;
    end
    
    intensity.exp = measures.total;
    transitivity.exp = measures.trans;
    transitivity.rel.exp = measures.trans/measures.total;
    intransitivity.exp = measures.intrans;
    intransitivity.rel.exp = measures.intrans/measures.total;
    rho.exp = measures.rho;
    
    %% Rank competitors
    [~,ranks.exp] = sort(ratings.exp,'descend');
    [~,ranks.mle] = sort(ratings.mle,'descend');
    
    fprintf(' Finished')
    
    %% Estimate percent of (squared) measures from noise
    measures.percent_from_noise = Estimate_Percent_Measures_from_Noise(G,f);
    
    %% check whether to sample from posterior
    if sampling_settings.on_off == 1
        fprintf('\n Sampling from Posterior: ')
        
        %% sample flow to get marginal distribution for measures
        %and confidence bounds from posterior, sample of ratings and rankings
        n_realization = sampling_settings.n_realization;
        confidence = sampling_settings.confidence;
        [transitivity.sampled.post,intransitivity.sampled.post,rho.sampled.post,...
            ratings.sampled.post,ranks.sampled.post] = ...
            Sample_f(n_realization,V,E,posterior_f,f,f_range,G,complete_flag,confidence);
        
        fprintf(' Finished')
        
        %% check whether to compare with samples from prior
        if sampling_settings.compare_to_prior == 1
            fprintf('\n Sampling from Prior for Comparison: ')
            
            %% sample from prior
            for k = 1:E
                prior{k} = @(flow) cosh(flow).^(-2*beta);
            end
            
            [transitivity.sampled.prior,intransitivity.sampled.prior,rho.sampled.prior,...
                ratings.sampled.prior,ranks.sampled.prior] = ...
                Sample_f(n_realization,V,E,prior,f,f_range,G,complete_flag,confidence);
            
            fprintf(' Finished')
            
            %% compute kolmogorov distance between empirical marginal distributions for measures
            transitivity.sampled.kolmogorov_post_prior =...
                max(abs(cumsum(transitivity.sampled.post.dist) -...
                cumsum(transitivity.sampled.prior.dist)));
            
            intransitivity.sampled.kolmogorov_post_prior =...
                max(abs(cumsum(intransitivity.sampled.post.dist) -...
                cumsum(intransitivity.sampled.prior.dist)));
            
            
            %% estimate kl divergence between marginal posterior and prior distributions
            
            
            
        end
        
    end
    
    %% Hypothesis testing
    if hypothesis_testing.on_off == 1
        %% test perfectly transitive
        fprintf('\n Testing Perfectly Transitive Hypothesis: ')
        hypothesis = 'perfectly transitive';
        [mle_models.perfectly_transitive] = Test_Hypothesis(hypothesis,V,E,gamma,wins,events,G,nan,ratings.mle);
        fprintf(' Finished')
        
        %% test perfectly cyclic
        fprintf('\n Testing Perfectly Cyclic Hypothesis: ')
        hypothesis = 'perfectly cyclic';
        [mle_models.perfectly_cyclic] = Test_Hypothesis(hypothesis,V,E,gamma,wins,events,G,f.rot.mle,nan);
        fprintf(' Finished')
        
        %% compare to mle
        fprintf('\n Testing MAP for Comparison: ')
        hypothesis = 'combination';
        [mle_models.mle] = Test_Hypothesis(hypothesis,V,E,gamma,wins,events,G,f.mle,ratings.mle);
        fprintf(' Finished')
        
    end
    
    
    %% Plausible Regions
    if plausible_region_settings.on_off == 1
        fprintf('\n Finding Plausible Region: ')
        bounds_to_find = plausible_region_settings.bounds_to_find;
        plausibility = plausible_region_settings.plausibility;
        plausible_bounds = Get_Plausible_Region(bounds_to_find,plausibility,...
            wins,events,gamma,G,transitivity.mle,intransitivity.mle,f.mle);
        fprintf(' Finished')
    end
    
    
    %% Format Output and Save Results
    % input
    output.input = input; % stores the input so can be recreated
    
    % topology
    output.topology.complete_flag = complete_flag;
    output.topology.adjacency_matrix = A;
    output.topology.adjacency_list = adjacency_list;
    output.topology.edge_to_endpoints = edge_to_endpoints;
    
    output.operators.gradient = G;
    
    output.dimensions.V = V;
    output.dimensions.E = E;
    output.dimensions.L = L;
    
    % prior
    output.prior.beta = beta;
    output.prior.gamma = gamma;
    
    % data oriented by edges and empirical win prob and log odds
    output.data.wins = wins;
    output.data.losses = losses;
    output.data.events = events;
    output.data.ties = ties;
    output.data.win_frequencies = wins./events;
    output.data.flow_empirical = (1/2)*(log(wins./events) - log(1 - wins./events));
    
    % flow
    output.f = f;
    
    % measures
    output.measures.total = intensity;
    output.measures.transitivity = transitivity;
    output.measures.intransitivity = intransitivity;
    output.measures.percent_from_noise = measures.percent_from_noise;
    output.measures.rho = rho;
    if plausible_region_settings.on_off == 1
        output.measures.plausible_bounds = plausible_bounds;
    end
    
    % ranking and rating
    output.rating = ratings;
    output.ranking = ranks;
    
    % vorticities and curl
    if complete_flag == 1
        output.vorticity = vorticities;
        output.operators.curl = C;
        output.operators.cycles = cycles;
    end
    
    % hypothesis testing
    if hypothesis_testing.on_off == 1
        output.hypothesis_testing = mle_models;
    end
    
    %% save
    path = '..\Results\'; % sends output file to results folder
    save(strcat(path,output_filename),'output')
    
    
    %% Print Results
    if display_settings.print_results == 1
        Print_Results(output);
    end
    
    
    %% Plot Results
    if display_settings.plot.on_off == 1
        Plot_Results(output);
    end
    
    
end


end
