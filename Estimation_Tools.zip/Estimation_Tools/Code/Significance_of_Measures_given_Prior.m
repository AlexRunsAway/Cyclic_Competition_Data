%% evlaluate statistical significance against prior

% significance of:
% 1. observed size of transitive component
% 2. observed size of cyclic component
% 3. observed relative intransitivity
% 4. observed correlation coefficient

% all using a one-sided p test

%%
clear

%% load data
load('../Results/Animals/Yasukawa_1983_4.mat')

%% get number of competitors
V = output.dimensions.V;
E = output.dimensions.E;

%% get prior parameter
beta = output.prior.beta;

%% get event counts
events = zeros([E,1]);
for k = 1:E
    i = output.topology.edge_to_endpoints(k,1);
    j = output.topology.edge_to_endpoints(k,2);
    events(k) = output.input.data.win_loss(i,j) + output.input.data.win_loss(j,i);
end

%% get estimated sizes of components, correlation
transitivity = output.measures.transitivity.exp;
intransitivity = output.measures.intransitivity.exp;
relative_intransitivity = output.measures.intransitivity.rel.exp;
rho = output.measures.rho.exp;

%% sample win probabilities
n_real = 10^5;
P = betarnd(beta,beta,[E,n_real]);

%% loop over realizations
for i = 1:n_real
    p = P(:,i);
    
    %% sample wins
    w = binornd(events,p);
    l = events - w;
    
    %% estimate flow
    f = (1/2)*(psi(w + beta) - psi(l + beta));
    
    %% compute sizes of components (perform HHD)
    G = output.operators.gradient;
    C = nan;
    complete_flag = output.topology.complete_flag;
    [~,~,~,measures] = Perform_HHD(f,G,complete_flag,C);
    
    trans_sample(i) = measures.trans;
    intrans_sample(i) = measures.intrans;
    rel_intrans_sample(i) = measures.intrans/measures.total;
    rho_sample(i) = measures.rho;
   
    
end

%% compute significance
p_values.trans = 1 - sum(trans_sample <= transitivity)/n_real; % fraction of samples more transitive than observed
p_values.intrans = 1 - sum(intrans_sample >= intransitivity)/n_real; % fraction of samples less cyclic than observed
p_values.rel_intrans = 1 - sum(rel_intrans_sample >= relative_intransitivity)/n_real; % fraction of samples less relatively cyclic than observed
p_values.rho = 1 - sum(rho_sample <= rho)/n_real; % fraction of samples more correlated