function [boundary, stop_flag] = Find_Plausible_Bound(plausibility_threshold,precision,...
    search_bounds,constraint_type,wins,events,gamma,G,f_mle)
%% runs a mixed bisection-secant search to find the plausible boundary

%% Inputs:
% 1. plausibility_threshold: defines what is plausible - looking for a
%boundary so that for the constrained mle given the bound the likelihood of
%sampling data equally or more suprising than the true data matches this
%threshold (this is the p in the p test)
% 2. precision: the precision to which the probability of sampling data that
%is equally or more suprising is calculated
% 3. search_bounds: [a,b] where a is the initial guess for a lower boundary
%in the bisection search, and b is an upper
% 4. constraint type: a string describing the constraint enforced by the
% boundary we are searching for
% 5. wins: the observed win data for each pair
% 6. events: the observed number of events for each pair
% 7. alpha: the parameter for the prior distribution (effective number of
% ties)
% 8. G: the gradient operator

%% Outputs
% 1. boundary: the boundary value for the constraint such that the
% probability of sampling data from the constrained mle that is equally or
% more suprising than the true data (given the constrained mle) equals the
% plausibility threshold
% 2. stop_flag: is a straing which describes what condition stopped the
% search

%% read constraint type
if strcmp(constraint_type,'absolute intransitivity lower')
    lower_or_upper = 1;
elseif strcmp(constraint_type,'absolute intransitivity upper')
    lower_or_upper = 2;
elseif strcmp(constraint_type,'absolute transitivity lower')
    lower_or_upper = 1;
elseif strcmp(constraint_type,'absolute transitivity upper')
    lower_or_upper = 2;
elseif strcmp(constraint_type,'relative intransitivity lower')
    lower_or_upper = 1;
elseif strcmp(constraint_type,'relative intransitivity upper')
    lower_or_upper = 2;
elseif strcmp(constraint_type,'forcing lower')
    lower_or_upper = 1;
elseif strcmp(constraint_type,'forcing upper')
    lower_or_upper = 2;
end

%% fix number of realizations to get within desired precision
n_real = 10*round(1/precision); % number of realizations for Monte Carlo, the extra 
% factor of ten means that we draw enough samples so the std in the
% estimated plausibility is a tenth the plausibility we are searching for


%% intialize bisection search
lower_boundary = search_bounds(1); % lower boundary for bisection search
upper_boundary = search_bounds(2); % upper boundary for bisection search
bound_found = 0; % tracks whether we have found a bound that matches the plausibility threshold (controls when to stop searching)

%% check lower search boundary
f_0 = f_mle;
[plausibility,f_opt_old] = Compute_Plausibility(wins,events,gamma,f_0,n_real,constraint_type,lower_boundary,G);

stop = 0;
while stop == 0
    if lower_or_upper == 1
        comparitor = plausibility - plausibility_threshold;
    else
        comparitor = plausibility_threshold - plausibility;
    end
    if comparitor <= 0
        % small enough, stop and accept lower boundary for search
        stop = 1;
        plausibility_lower = plausibility;
    else
        % not small enough, reduce lower boundary
        lower_boundary = lower_boundary/10;
        
        % recompute plausibility, start optimizer from old optimal soln
        f_0 = f_opt_old;
        [plausibility,f_opt_old] = Compute_Plausibility(wins,events,gamma,f_0,n_real,constraint_type,lower_boundary,G);
        
        if lower_boundary < 10^(-10)
            % close enough to zero to treat as zero
            stop = 1;
            bound_found = 1;
            boundary = 0;
            stop_flag = 'lower bound plausible for bounds >= 10^(-10)';
        end
    end
end

%% check upper search boundary
f_0 = f_mle;
[plausibility,f_opt_old] = Compute_Plausibility(wins,events,gamma,f_0,n_real,constraint_type,upper_boundary,G);

stop = 0;
while stop == 0
    if lower_or_upper == 1
        comparitor = plausibility - plausibility_threshold;
    else
        comparitor = plausibility_threshold - plausibility;
    end
    if comparitor >= 0
        % large enough, stop and accept lower boundary for search
        stop = 1;
        plausibility_upper = plausibility;
    else
        % not large enough, increase upper boundary
        upper_boundary = upper_boundary*10;
        
        % recompute plausibility
        f_0 = f_opt_old;
        [plausibility,f_opt_old] = Compute_Plausibility(wins,events,gamma,f_0,n_real,constraint_type,upper_boundary,G);
        
        if upper_boundary > 10^(10)
            % large enough to stop
            stop = 1;
            bound_found = 1;
            boundary = upper_boundary;
            stop_flag = 'upper bound plausible for bounds <= 10^(10)';
        end
    end
end



%% bisect/secant search
if bound_found == 0
    
    %% initialize search and set stop conditions
    max_it = 40;
    plaus_difference = abs(plausibility_upper - plausibility_lower);
    if plaus_difference < min(10*precision,0.1)
        slope = (plausibility_upper - plausibility_lower)/(upper_boundary - lower_boundary);
        bound = lower_boundary + (plausibility_threshold - plausibility_lower)/slope;
    else
        bound = (lower_boundary + upper_boundary)/2;
    end
    stop = 0;
    it = 0;
    
    while stop == 0
        %% evaluate plausibility
        n_real_req = min(10*n_real,... % at most don't require more precision in estimated plausibility than precision/3
            100*round(1/min(abs(plausibility_upper - plausibility_threshold),...
            abs(plausibility_lower - plausibility_threshold)))); % otherwise only need to be 10 times more precise than the distance from threshold
        
        if it == 0
            f_0 = f_mle;
        else  
            f_0 = f_opt_old;
        end
        [plausibility,f_opt_old] = Compute_Plausibility(wins,events,gamma,f_0,n_real_req,constraint_type,bound,G);
        
        %% print
        msg = sprintf('\n Boundary: %f, Plausibility: %f', bound,plausibility);
        if it > 0
            fprintf([reverseStr, msg])
        else
            fprintf(msg)
        end
        reverseStr = repmat(sprintf('\b'), 1, length(msg));
        
        %% check stopping criteria
        if abs(plausibility - plausibility_threshold) <= precision
            stop = 1;
            boundary = bound;
            stop_flag = 'stopped on convergence to desired plausibility';
            
            %% print
            fprintf(reverseStr)
            
        elseif it > max_it
            stop = 1;
            boundary = bound;
            stop_flag = 'stopped on iteration count';
            
            %% print
            fprintf(reverseStr)
        end
        
        if stop == 0
            %% update if haven't stopped
            it = it + 1;
            if lower_or_upper == 1
                comparitor = plausibility - plausibility_threshold;
            else
                comparitor = plausibility_threshold - plausibility;
            end
            if comparitor < 0
                lower_boundary = bound;
                plausibility_lower = plausibility;
            else
                upper_boundary = bound;
                plausibility_upper = plausibility;
            end
            
            plaus_difference = abs(plausibility_upper - plausibility_lower);
            if plaus_difference < min(10*precision,0.1) % secant when close
                slope = (plausibility_upper - plausibility_lower)/(upper_boundary - lower_boundary);
                bound = lower_boundary + (plausibility_threshold - plausibility_lower)/slope;
            else
                bound = (lower_boundary + upper_boundary)/2; % bisection while far from convergence
            end
            
        end
        
    end
    
    
    
    
end


end