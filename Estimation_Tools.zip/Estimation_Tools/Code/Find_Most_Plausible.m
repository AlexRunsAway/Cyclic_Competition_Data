function [output] = Find_Most_Plausible(input)
end