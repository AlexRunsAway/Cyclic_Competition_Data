function Print_Results(input)

fprintf('\n\n\n <strong> Results: </strong> ')

%% gamma
fprintf('\n\n <strong> Parameters for Prior: </strong> ')
fprintf('\n beta = %f',input.prior.beta)
if input.input.settings.display.print_results == 1
    fprintf('\n See plot: Win Frequencies and Prior ')
end

%% ranking and rating
fprintf('\n\n <strong> Ranking and Rating: </strong> ')
fprintf('\n\n <strong> Ranking by Expected and MAP Flow  (1st and 2nd columns) </strong> \n')
names = input.input.names;
ranks = input.ranking;
ratings = input.rating;
V = input.dimensions.V;
for j = 1:V
fprintf('Competitor Rank %d:', j)
disp(strcat( names{1}(ranks.exp(j)),{'   '},'Rating: ',num2str(ratings.exp(ranks.exp(j)),3)...
    ,{'    '}, names{1}(ranks.mle(j)), {'    '},'Rating: ',num2str(ratings.mle(ranks.mle(j)),3)))
end

if input.input.settings.display.print_results == 1
    fprintf('\n See plot: Ratings ')
end

if input.input.settings.sampling.on_off == 1
    correlations = input.ranking.sampled.post.correlation;
    fprintf('\n\n <strong> Uncertainty in Ranking (from sampling posterior): </strong>')
    fprintf('\n Spearman Rank Correlation: %f, Kendall tau: %f \n',correlations.Spearman, correlations.Kendall)
    
    fprintf('\n\n <strong> Uncertainty in Ratings (from sampling posterior): </strong> \n')
    rating_var = input.rating.sampled.post.var;
    for j = 1:V
        fprintf('Competitor Rank %d:', j)
        disp(strcat( names{1}(ranks.exp(j)),{'   '},'STD in Ratings:', num2str(sqrt(rating_var(j)),3)) )
    end
    
    if input.input.settings.display.print_results == 1
        fprintf('\n See plots: Ratings Distribution, Rankings Distribution')
    end
end


%% sizes of flow and components
fprintf('\n\n <strong> Sizes of Flow and Components: </strong> ')
if input.input.settings.display.print_results == 1
    fprintf('\n See plots: Edge Flow, Cyclic Flow, Large Edge Flows, Large Transitive Edge Flows, \n and Large Cyclic Edge Flows  ')
end

% point estimators
fprintf('\n\n <strong> Results from Point Estimators: </strong> ')
total = input.measures.total;
transitivity = input.measures.transitivity;
intransitivity = input.measures.intransitivity;

fprintf('\n Size of Expected Flow: %f',norm(total.exp))
fprintf('\n Transitivity in Expected Flow. Absolute: %f, Relative: %f',transitivity.exp,transitivity.rel.exp)
fprintf('\n Intransitivity in Expected Flow. Absolute: %f, Relative: %f',intransitivity.exp,intransitivity.rel.exp)

fprintf('\n Size of MAP Flow: %f',norm(total.mle))
fprintf('\n Transitivity in MAP Flow. Absolute: %f, Relative: %f',transitivity.mle,transitivity.rel.mle)
fprintf('\n Intransitivity in MAP Flow. Absolute: %f, Relative: %f',intransitivity.mle,intransitivity.rel.mle)

% sampling
if input.input.settings.sampling.on_off == 1
    
    fprintf('\n\n <strong> Results from Sampling Posterior: </strong>')
    fprintf('\n Expected Transitivity: %f, Standard Deviation: %f, \n 95 percent confidence lower bound: %f, upper bound: %f',...
        transitivity.sampled.post.expected, sqrt(transitivity.sampled.post.variance),...
        transitivity.sampled.post.lower, transitivity.sampled.post.upper)
    fprintf('\n Expected Intransitivity: %f, Standard Deviation: %f, \n 95 percent confidence lower bound: %f, upper bound: %f',...
        intransitivity.sampled.post.expected, sqrt(intransitivity.sampled.post.variance),...
        intransitivity.sampled.post.lower, intransitivity.sampled.post.upper)
    
    
    if input.input.settings.sampling.compare_to_prior == 1
        fprintf('\n\n <strong> Comparison to Results when Sampled From Prior </strong>')
        fprintf('\n Expected Transitivity: %f, Standard Deviation: %f, \n 95 percent confidence lower bound: %f, upper bound: %f',...
        transitivity.sampled.prior.expected, sqrt(transitivity.sampled.prior.variance),...
        transitivity.sampled.prior.lower, transitivity.sampled.prior.upper)
    fprintf('\n Expected Intransitivity: %f, Standard Deviation: %f, \n 95 percent confidence lower bound: %f, upper bound: %f',...
        intransitivity.sampled.prior.expected, sqrt(intransitivity.sampled.prior.variance),...
        intransitivity.sampled.prior.lower, intransitivity.sampled.prior.upper)
    fprintf('\n Kolmogorov Distance from Prior to Posterior Marginals: ')
    fprintf('\n Transitivity: %f, Intransitivity: %f',...
        transitivity.sampled.kolmogorov_post_prior,intransitivity.sampled.kolmogorov_post_prior)
    end
    
    if input.input.settings.display.print_results == 1
        fprintf('\n See plot: Marginal Posterior Distribution for Measures ')
    end
end

% plausible regions
plausible_region_settings = input.input.settings.plausible_regions;
if plausible_region_settings.on_off == 1
    fprintf('\n\n <strong> Plausible Bounds: </strong> ')
    
    if plausible_region_settings.bounds_to_find.min_trans == 1
        bound = input.measures.plausible_bounds.trans.lower;
        fprintf('\n Smallest Transitivity Plausible: %f', bound);
    end
    
    if plausible_region_settings.bounds_to_find.max_trans == 1
        bound = input.measures.plausible_bounds.trans.upper;
        fprintf('\n Largest Transitivity Plausible: %f', bound);
    end
    
    if plausible_region_settings.bounds_to_find.min_intrans == 1
        bound = input.measures.plausible_bounds.intrans.lower;
        fprintf('\n Smallest Intransitivity Plausible: %f', bound);
    end
    
    if plausible_region_settings.bounds_to_find.max_intrans == 1
        bound = input.measures.plausible_bounds.intrans.upper;
        fprintf('\n Largest Intransitivity Plausible: %f', bound);
    end
    
    if input.input.settings.display.print_results == 1
        fprintf('\n See plot: Plausible Region ')
    end
end






%% Hypothesis Testing
if input.input.settings.hypothesis_testing.on_off == 1
    fprintf('\n\n\n <strong> Hypothesis Testing: </strong> ')
    
    perfectly_transitive = input.hypothesis_testing.perfectly_transitive;
    perfectly_cyclic = input.hypothesis_testing.perfectly_cyclic;
    mle = input.hypothesis_testing.mle;
    
    fprintf('\n\n <strong> log likelihood: </strong> ')
    fprintf('\n MAP Perfectly Transitive Model: %.2f',perfectly_transitive.match_to_data.log_likelihood)
    fprintf('\n MAP Perfectly Cyclic Model: %.2f',perfectly_cyclic.match_to_data.log_likelihood)
    fprintf('\n MAP Model: %.2f',mle.match_to_data.log_likelihood)
    
    fprintf('\n\n <strong> AIC: </strong> ')
    fprintf('\n MAP Perfectly Transitive Model: %.2f',perfectly_transitive.match_to_data.AIC)
    fprintf('\n MAP Perfectly Cyclic Model: %.2f',perfectly_cyclic.match_to_data.AIC)
    fprintf('\n MAP Model: %.2f',mle.match_to_data.AIC)
    
    fprintf('\n\n <strong> Percent of Observed Win Frequencies within Confidence Intervals given Model: </strong> ')
    fprintf('\n 50 Percent Confidence: Perfectly Transitive: %.2f, Perfectly Cyclic: %.2f, MAP: %.2f',...
        100*perfectly_transitive.match_to_data.percent_edges_in_50,...
        100*perfectly_cyclic.match_to_data.percent_edges_in_50,...
        100*mle.match_to_data.percent_edges_in_50)
    fprintf('\n 95 Percent Confidence: Perfectly Transitive: %.2f, Perfectly Cyclic: %.2f, MAP: %.2f',...
        100*perfectly_transitive.match_to_data.percent_edges_in_95,...
        100*perfectly_cyclic.match_to_data.percent_edges_in_95,...
        100*mle.match_to_data.percent_edges_in_95)
    
    
    fprintf('\n\n <strong> Plausibility (to 0.01): </strong> ')
    fprintf('\n MAP Perfectly Transitive Model: %.2f',perfectly_transitive.match_to_data.plausibility)
    fprintf('\n MAP Perfectly Cyclic Model: %.2f',perfectly_cyclic.match_to_data.plausibility)
    fprintf('\n MAP Model: %.2f',mle.match_to_data.plausibility)
    
    
    endpoints = input.topology.edge_to_endpoints;
    f = input.f;
    
    fprintf('\n\n <strong> Five Pairs Worst Described by Model: </strong> ')
    fprintf('\n Probabilities are of sampling the observed win frequency, \n or a less likely win frequency, given the model.')
    fprintf('\n\n <strong> Perfectly Transitive Model: </strong>')
    [~,order] = sort(perfectly_transitive.match_to_data_per_edge.p_test_two_sided,'ascend');
    for j = 1:min(5,input.dimensions.E)
        edge = order(j);
        if f.mle(edge) > 0
            start = endpoints(edge,1);
            finish = endpoints(edge,2);
            sign = 1;
        else
            start = endpoints(edge,2);
            finish = endpoints(edge,1);
            sign = -1;
        end
        competitor_string = strcat(names{1}(start),' > ',{' '},names{1}(finish));
        fprintf('\n Pair %s, MAP Intransitive Flow: %.2f, Probability:   ',competitor_string{1},sign*f.rot.mle(edge))
        disp(perfectly_transitive.match_to_data_per_edge.p_test_two_sided(order(j)));
    end
    
    fprintf('\n\n <strong> Perfectly Cyclic Model: </strong>')
    [~,order] = sort(perfectly_cyclic.match_to_data_per_edge.p_test_two_sided,'ascend');
    for j = 1:min(5,input.dimensions.E)
        edge = order(j);
        if f.mle(edge) > 0
            start = endpoints(edge,1);
            finish = endpoints(edge,2);
            sign = 1;
        else
            start = endpoints(edge,2);
            finish = endpoints(edge,1);
            sign = -1;
        end
        competitor_string = strcat(names{1}(start),' > ',{' '},names{1}(finish));
        fprintf('\n Pair %s, MAP Transitive Flow: %.2f, Probability:   ',competitor_string{1},sign*f.con.mle(edge))
        disp(perfectly_cyclic.match_to_data_per_edge.p_test_two_sided(order(j)));
    end
    
    
    fprintf('\n\n <strong> MAP Model: </strong>')
    [~,order] = sort(mle.match_to_data_per_edge.p_test_two_sided,'ascend');
    for j = 1:min(5,input.dimensions.E)
        edge = order(j);
        if f.mle(edge) > 0
            start = endpoints(edge,1);
            finish = endpoints(edge,2);
        else
            start = endpoints(edge,2);
            finish = endpoints(edge,1);
        end
        competitor_string = strcat(names{1}(start),' > ',{' '},names{1}(finish));
        fprintf('\n Pair %s, Probability:   ',competitor_string{1})
        disp(mle.match_to_data_per_edge.p_test_two_sided(order(j)));
    end
    
    if input.input.settings.display.print_results == 1
        fprintf('\n See plot Match to Data Scatter, or plots ending in ``Match to Data" ')
    end
    
end




end