function [bounds] = Get_Plausible_Region(bounds_to_find,plausibility_threshold,...
    wins,events,gamma,G,trans_mle,intrans_mle,f_mle)


%% compute precision
precision = plausibility_threshold/10; % stop when within a decimal place of desired plausibility

%% search for bounds
% idea: say we want the min intransitivity. This is the smallest
% the intransitivity could be while admitting a model that is plausible.
% This means that we need to search the space of models with intransitivity
% beneath this bound for the most plausible model. So we propose a min
% intransitivity, then search the space of models with intransitivity less
% than it. We find the model in this space that maximizes the plausibility
% (or is most likely if required for computation time), then ask, is this
% model plausible? If the model is plausible we lower the min intrans, if
% it isn't plausible we increase the min intrans (shrink or expand the
% admissable space of models). We do this until we find the smallest
% upper bound on intransitivity such that there is a plausible model.

if bounds_to_find.min_trans == 1 % lower bound on transitivity
    msg = 'Searching for Smallest Plausible Transitivity';
    fprintf(msg)
    
    constraint_type = 'absolute transitivity lower';
    search_bounds = [1/8,1.2]*trans_mle; %initial guess at a window containing the bound we are looking for
    [boundary, stop_flag] = Find_Plausible_Bound(plausibility_threshold,precision,...
        search_bounds,constraint_type,wins,events,gamma,G,f_mle);
    bounds.trans.lower = boundary;
    bounds.trans.lower_stop_flag = stop_flag;
    
    reverseStr = repmat(sprintf('\b'), 1, length(msg));
    fprintf(reverseStr)
end

if bounds_to_find.max_trans == 1 % upper bound on transitivity
    msg = 'Searching for Largest Plausible Transitivity';
    fprintf(msg)
    
    constraint_type = 'absolute transitivity upper';
    search_bounds = [0.8,8]*trans_mle; %initial guess at a window containing the bound we are looking for
    [boundary, stop_flag] = Find_Plausible_Bound(plausibility_threshold,precision,...
        search_bounds,constraint_type,wins,events,gamma,G,f_mle);
    bounds.trans.upper = boundary;
    bounds.trans.upper_stop_flag = stop_flag;
    
    reverseStr = repmat(sprintf('\b'), 1, length(msg));
    fprintf(reverseStr)
end

if bounds_to_find.min_intrans == 1 % lower bound on intransitivity
    msg = 'Searching for Smallest Plausible Intransitivity';
    fprintf(msg)
    
    constraint_type = 'absolute intransitivity lower';
    search_bounds = [1/8,1.2]*intrans_mle; %initial guess at a window containing the bound we are looking for
    [boundary, stop_flag] = Find_Plausible_Bound(plausibility_threshold,precision,...
        search_bounds,constraint_type,wins,events,gamma,G,f_mle);
    bounds.intrans.lower = boundary;
    bounds.intrans.lower_stop_flag = stop_flag;
    
    reverseStr = repmat(sprintf('\b'), 1, length(msg));
    fprintf(reverseStr)
end

if bounds_to_find.max_intrans == 1 % upper bound on intransitivity
    msg = 'Searching for Largest Plausible Intransitivity';
    fprintf(msg)
    
    constraint_type = 'absolute intransitivity upper';
    search_bounds = [0.8,8]*intrans_mle; %initial guess at a window containing the bound we are looking for
    [boundary, stop_flag] = Find_Plausible_Bound(plausibility_threshold,precision,...
        search_bounds,constraint_type,wins,events,gamma,G,f_mle);
    bounds.intrans.upper = boundary;
    bounds.intrans.upper_stop_flag = stop_flag;
    
    reverseStr = repmat(sprintf('\b'), 1, length(msg));
    fprintf(reverseStr)
end

end