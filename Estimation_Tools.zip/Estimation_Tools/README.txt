This is the HHD Estimation Toolbox.

It is divided into 5 folders:

1. Code: holds the code
2. Results: stores results from running the code
3. Default_Settings: stores defaults that are used by the code
4. Documentation: contains .txt files containing documentation that is called by the code
5. Data: stores the data analyzed by the code.

To get started open the Code folder. Inside the code folder open and run the MatLab function Main_Menu. 

This will open a series of menus that will walk you through the process of loading data, selecting estimation settings, and formatting the output. Documentation is provided along the way. 

The examples used in the paper ____________________ are provided. These can be loaded so that you can replicate the reported results, and to model the code. It is recommended that you familiarize yourself with the code with one of these examples before trying your own data.

To try one of the buil-in examples follow the following steps:

1. Open the folder labelled Code.
2. Open and run the file Main_Menu.mat
3. A window will now appear labelled "Data Menu". In this menu you choose what data to analyze.
4. In the data menu select "Use Built-In Example" from the first dropdown menu
5. Pick an example from the dropdown menu that appears (recommend "Parliamentary Polling Data")
6. Once you pick an example a button labelled "Load Data" will appear in the bottom left. Click it.
7. This opens the "Settings Menu". In this menu you can select the settings used by the estimator.
8. The first dropdown provided allows you to pick an initial settings configuration. Start by picking "Complete Analysis". This turns all the possible estimation options on.
9. The specific settings will now appear. Documentation on each is provided. You can modify these here as desired.
10. To practice modifying a settings open the drop down menu under "Prio Settings" that reads "Use Win Loss..." and change it to "Use Additional Win Frequency Data"
11. You now have the option to save these settings as a new default, which you could use in the future by selecting as the initial settings, or you can progress straight to the estimator.
12. Click "Open Output Menu" to progress to the output menu.
13. Leave both the options to print and plot results on.
14. In the space next to "File to Save Results to: " type test.
15. A button labelled "RUN!" will appear. Click it.

This will close the menus and start the estimation process. To monitor the process watch the print out in your workspace.
